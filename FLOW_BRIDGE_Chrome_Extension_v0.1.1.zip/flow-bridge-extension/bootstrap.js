/**
 * Flow Bridge Chrome Extension — Isolated World Bootstrap & Security Gate (S1 Correction V3)
 * Runs in ISOLATED world at document_start.
 * 
 * Responsibilities:
 * 1. Read local verified control state from chrome.storage.local.
 * 2. Evaluate bounded last-known-good (LKG) policy and broadcast local gate decision to MAIN world.
 * 3. React to live chrome.storage changes (remote kill switch, updates) and update MAIN world gate in real-time.
 * 4. Relay neutral technical diagnostics to popup and storage.
 * 
 * Invariants:
 * - NO remote network requests in page critical path.
 * - Fail closed if no verified control exists.
 */

'use strict';

(function() {
  let cachedDiag = null;
  const mainWorldPorts = new Set();
  const MAX_PORTS = 8;
  let lastEvaluatedDecision = null;

  function broadcastDisableSignal() {
    for (const port of mainWorldPorts) {
      try {
        port.postMessage({ source: 'flow-bridge-control', action: 'DISABLE' });
      } catch (_) {
        mainWorldPorts.delete(port);
      }
    }
    try {
      window.postMessage({ source: 'flow-bridge-control', action: 'DISABLE' }, '*');
    } catch (_) {}
    try {
      if (document.documentElement) {
        document.documentElement.dataset.flowBridgeDisabled = 'true';
      }
    } catch (_) {}
  }
  const initTime = new Date().toISOString();
  console.log('[Flow Bridge Isolated Bootstrap] Extension content script active at document_start:', initTime, 'readyState:', document.readyState);

  function updateInPageBanner(decision) {
    const BANNER_ID = 'flow-bridge-inpage-notice-banner';

    function ensureDomReady(fn) {
      if (document.body) {
        fn();
      } else {
        document.addEventListener('DOMContentLoaded', fn, { once: true });
      }
    }

    if (!decision || decision.allow_patch === true) {
      ensureDomReady(function() {
        const existing = document.getElementById(BANNER_ID);
        if (existing) {
          // If banner was shown due to previous disable, guide user to reload page
          existing.style.backgroundColor = '#15291e';
          existing.style.borderColor = '#38a169';
          existing.innerHTML = `
            <div style="font-weight: 700; font-size: 12.5px; display: flex; align-items: center; gap: 6px; color: #48bb78;">
              ⚡ FLOW BRIDGE: Работа восстановлена
            </div>
            <div style="font-size: 11px; color: #cbd5e0;">
              Для возобновления работы расширения нажмите кнопку «Обновить страницу» или перезагрузите вкладку.
            </div>
            <div style="display: flex; gap: 8px; margin-top: 4px;">
              <button id="fb-reload-page-btn" style="padding: 5px 10px; background: #38a169; color: #ffffff; border: none; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                🔄 Обновить страницу
              </button>
              <button id="fb-close-banner-btn" style="padding: 5px 8px; background: rgba(255,255,255,0.12); border: none; color: #cbd5e0; border-radius: 4px; font-size: 11px; cursor: pointer;">
                ✕ Скрыть
              </button>
            </div>
          `;
          const reloadBtn = document.getElementById('fb-reload-page-btn');
          if (reloadBtn) reloadBtn.onclick = () => window.location.reload();
          const closeBtn = document.getElementById('fb-close-banner-btn');
          if (closeBtn) closeBtn.onclick = () => { existing.style.opacity = '0'; setTimeout(() => existing.remove(), 300); };
        }
      });
      return;
    }

    // Render banner for non-active states (DISABLED, MAINTENANCE, UPDATE_REQUIRED)
    ensureDomReady(function() {
      let banner = document.getElementById(BANNER_ID);
      if (!banner) {
        banner = document.createElement('div');
        banner.id = BANNER_ID;
        banner.style.cssText = [
          'position: fixed',
          'top: 14px',
          'right: 14px',
          'z-index: 2147483647',
          'max-width: 400px',
          'padding: 12px 14px',
          'border-radius: 8px',
          'font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
          'font-size: 12px',
          'line-height: 1.4',
          'color: #ffffff',
          'box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6)',
          'display: flex',
          'flex-direction: column',
          'gap: 6px',
          'border: 1px solid rgba(255, 255, 255, 0.15)',
          'backdrop-filter: blur(8px)',
          'transition: opacity 0.3s ease'
        ].join(';');
        document.body.appendChild(banner);
      }

      let title = 'FLOW BRIDGE · Не удалось проверить состояние';
      let titleColor = '#e2e8f0';
      let msg = 'Не удалось проверить состояние. Проверьте соединение и повторите попытку.';
      let bgColor = '#1a202c';
      let borderColor = '#718096';

      if (decision.state === 'DISABLED' || decision.state === 'MAINTENANCE') {
        title = 'FLOW BRIDGE · Техработы';
        titleColor = '#f6ad55';
        msg = 'Сейчас идёт плановое обслуживание программы.<br>В ближайшее время работа восстановится.<br>Актуальная информация — в Telegram-группе.';
        bgColor = '#1c1b18';
        borderColor = '#d97706';
      } else if (decision.state === 'UPDATE_REQUIRED') {
        title = '⚡ FLOW BRIDGE: Требуется обновление';
        titleColor = '#fbd38d';
        msg = 'Установленная версия устарела. Для продолжения работы обновите расширение.';
        bgColor = '#2d1c12';
        borderColor = '#dd6b20';
      }

      banner.style.backgroundColor = bgColor;
      banner.style.borderColor = borderColor;

      banner.innerHTML = `
        <div style="font-weight: 700; font-size: 12.5px; display: flex; align-items: center; gap: 6px; color: ${titleColor};">
          ${title}
        </div>
        <div style="font-size: 11.5px; color: #e2e8f0; line-height: 1.45;">
          ${msg}
        </div>
        <div style="display: flex; gap: 8px; margin-top: 4px;">
          <a href="https://t.me/ITHRONIC" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 4px; padding: 5px 10px; background: #0088cc; color: #ffffff; text-decoration: none; border-radius: 4px; font-size: 11px; font-weight: 600;">
            ✈️ Перейти в Telegram
          </a>
          <button id="fb-close-banner-btn" style="padding: 5px 8px; background: rgba(255,255,255,0.12); border: none; color: #cbd5e0; border-radius: 4px; font-size: 11px; cursor: pointer;">
            ✕ Скрыть
          </button>
        </div>
      `;

      const closeBtn = document.getElementById('fb-close-banner-btn');
      if (closeBtn) {
        closeBtn.onclick = function() {
          banner.style.opacity = '0';
          setTimeout(() => banner.remove(), 300);
        };
      }
    });
  }

  function checkAndNotifyDisable(verifiedControlRecord) {
    const installedVersion = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '0.1.0';
    const nowMs = Date.now();

    let decision;
    if (verifiedControlRecord && verifiedControlRecord.verified_manifest && typeof __FLOW_BRIDGE_CRYPTO__ !== 'undefined') {
      decision = __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(
        verifiedControlRecord.verified_manifest,
        installedVersion,
        nowMs
      );
    } else {
      decision = {
        allow_patch: false,
        state: 'CONTROL_UNAVAILABLE',
        reason: 'FIRST_INSTALL_NO_VERIFIED_CONTROL',
        lkg_status: 'NONE'
      };
    }

    lastEvaluatedDecision = decision;
    updateInPageBanner(decision);

    if (decision.allow_patch === false) {
      broadcastDisableSignal();
    }
  }

  // Initial check of local verified control at document_start
  if (chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['flow_bridge_verified_control'], function(res) {
      const storedRecord = res ? res.flow_bridge_verified_control : null;
      checkAndNotifyDisable(storedRecord);
    });

    // Proactively request background service worker to sync latest control manifest
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: 'REFRESH_REMOTE_CONTROL' }, function() {});
      window.addEventListener('focus', function() {
        chrome.runtime.sendMessage({ type: 'REFRESH_REMOTE_CONTROL' }, function() {});
      });
    }

    // Listen for real-time control updates from background service worker
    chrome.storage.onChanged.addListener(function(changes, areaName) {
      if (areaName === 'local' && changes.flow_bridge_verified_control) {
        const newRecord = changes.flow_bridge_verified_control.newValue;
        checkAndNotifyDisable(newRecord);
      }
    });
  } else {
    // If storage is completely unavailable, broadcast disable
    broadcastDisableSignal();
  }

  // Listen for direct runtime disable messages
  if (chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function(request) {
      if (request && request.type === 'FLOW_BRIDGE_DISABLE') {
        broadcastDisableSignal();
      }
    });
  }

  // VULN-002 Hardening: Strict Schema Validation & Bounded Size for Diagnostics
  // Aligned with diagnostics.js getSanitizedSnapshot() schema
  function validateDiagnosticSchema(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return null;

    let jsonStr;
    try {
      jsonStr = JSON.stringify(payload);
      if (jsonStr.length > 16384) return null; // Enforce 16KB ceiling against storage exhaustion
    } catch (_) {
      return null;
    }

    const sanitized = {};

    // String fields
    if (typeof payload.extension_version === 'string' && /^[0-9.]{1,16}$/.test(payload.extension_version)) {
      sanitized.extension_version = payload.extension_version;
    }
    if (typeof payload.current_target === 'string' && /^[a-zA-Z0-9.-]{1,64}$/.test(payload.current_target)) {
      sanitized.current_target = payload.current_target;
    }
    if (typeof payload.current_url_path === 'string' && payload.current_url_path.length <= 256) {
      sanitized.current_url_path = payload.current_url_path;
    }
    if (typeof payload.current_url === 'string' && payload.current_url.length <= 512) {
      sanitized.current_url = payload.current_url;
    }
    if (typeof payload.navigation_id === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(payload.navigation_id)) {
      sanitized.navigation_id = payload.navigation_id;
    }
    if (typeof payload.nav_type === 'string' && /^[a-zA-Z0-9_-]{1,32}$/.test(payload.nav_type)) {
      sanitized.nav_type = payload.nav_type;
    }
    if (typeof payload.tab_id === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(payload.tab_id)) {
      sanitized.tab_id = payload.tab_id;
    }
    if (typeof payload.initial_ready_state === 'string' && /^[a-zA-Z0-9_-]{1,32}$/.test(payload.initial_ready_state)) {
      sanitized.initial_ready_state = payload.initial_ready_state;
    }
    if (typeof payload.current_ready_state === 'string' && /^[a-zA-Z0-9_-]{1,32}$/.test(payload.current_ready_state)) {
      sanitized.current_ready_state = payload.current_ready_state;
    }
    if (typeof payload.bootstrap_timestamp === 'string' && payload.bootstrap_timestamp.length <= 64) {
      sanitized.bootstrap_timestamp = payload.bootstrap_timestamp;
    }
    if (typeof payload.last_navigation_timestamp === 'string' && payload.last_navigation_timestamp.length <= 64) {
      sanitized.last_navigation_timestamp = payload.last_navigation_timestamp;
    }
    if (typeof payload.last_update_timestamp === 'string' && payload.last_update_timestamp.length <= 64) {
      sanitized.last_update_timestamp = payload.last_update_timestamp;
    }

    // Boolean fields
    const boolFields = [
      'is_fresh_tab',
      'main_world_initialized',
      'fetch_hook_installed',
      'xhr_hook_installed',
      'first_call_observed'
    ];
    for (const bField of boolFields) {
      if (typeof payload[bField] === 'boolean') {
        sanitized[bField] = payload[bField];
      }
    }

    // Preservation of hook_persistence object (diagnostics.js compatibility)
    if (payload.hook_persistence && typeof payload.hook_persistence === 'object' && !Array.isArray(payload.hook_persistence)) {
      sanitized.hook_persistence = {
        fetch_hook_intact: Boolean(payload.hook_persistence.fetch_hook_intact === true),
        xhr_hook_intact: Boolean(payload.hook_persistence.xhr_hook_intact === true),
        check_timestamp: (typeof payload.hook_persistence.check_timestamp === 'string' && payload.hook_persistence.check_timestamp.length <= 64)
          ? payload.hook_persistence.check_timestamp
          : new Date().toISOString()
      };
    }

    // Numeric counters (0 to 1,000,000)
    const counterFields = [
      'matched_response_count',
      'transformation_applied_count',
      'signout_prevented_count',
      'batchexecute_patched_count',
      'availability_patched_count',
      'protobuf_rpc_patched_count',
      'fetch_intercepted_count',
      'xhr_intercepted_count'
    ];
    for (const cField of counterFields) {
      const val = payload[cField];
      if (typeof val === 'number' && Number.isInteger(val) && val >= 0 && val <= 1000000) {
        sanitized[cField] = val;
      } else {
        sanitized[cField] = 0;
      }
    }

    // Arrays
    if (Array.isArray(payload.matched_families)) {
      sanitized.matched_families = payload.matched_families
        .filter(item => typeof item === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(item))
        .slice(0, 10);
    }
    if (Array.isArray(payload.ordering_sequence)) {
      sanitized.ordering_sequence = payload.ordering_sequence
        .slice(0, 50)
        .map(evt => {
          if (!evt || typeof evt !== 'object') return null;
          const cleanEvt = {};
          if (typeof evt.event === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(evt.event)) {
            cleanEvt.event = evt.event;
          }
          if (typeof evt.timestamp === 'string' && evt.timestamp.length <= 64) {
            cleanEvt.timestamp = evt.timestamp;
          }
          if (typeof evt.seq === 'number' && Number.isInteger(evt.seq) && evt.seq >= 0) {
            cleanEvt.seq = evt.seq;
          }
          if (typeof evt.ready_state === 'string' && /^[a-zA-Z0-9_-]{1,32}$/.test(evt.ready_state)) {
            cleanEvt.ready_state = evt.ready_state;
          }
          if (typeof evt.perf_ms === 'number' && Number.isFinite(evt.perf_ms)) {
            cleanEvt.perf_ms = evt.perf_ms;
          }
          return cleanEvt;
        })
        .filter(Boolean);
    }

    // Explicit advisory tag (MAIN world telemetry is unauthenticated advisory data)
    // Note: Schema validation provides memory/type bounds, but does NOT certify against in-page spoofing.
    sanitized.telemetry_source = 'MAIN_WORLD_ADVISORY';

    return sanitized;
  }

  function storeTechnicalTelemetry(payload) {
    if (!chrome.storage || !chrome.storage.local) return;
    const validated = validateDiagnosticSchema(payload);
    if (!validated) {
      console.warn('[Flow Bridge Bootstrap] Diagnostic payload rejected by schema/size gate');
      return;
    }
    cachedDiag = validated;

    chrome.storage.local.set({
      flow_bridge_latest_diag: validated,
      flow_bridge_last_update: new Date().toISOString()
    });
  }

  // Listen for messages from MAIN world
  window.addEventListener('message', function(event) {
    if (!event.data) return;

    // VULN-003 Hardening: Accept MessagePort handshake offers without single-port latching
    // Uses FIFO eviction if capacity is reached so that pre-filling MAX_PORTS cannot lock out legitimate ports.
    if (event.data.source === 'flow-bridge-main-handshake' && event.data.type === 'PORT_OFFER') {
      if (event.ports && event.ports[0]) {
        const port = event.ports[0];
        if (mainWorldPorts.size >= MAX_PORTS) {
          const oldestPort = mainWorldPorts.values().next().value;
          mainWorldPorts.delete(oldestPort);
        }
        mainWorldPorts.add(port);
        try {
          port.onmessageerror = function() { mainWorldPorts.delete(port); };
        } catch (_) {}

        // If current policy already determined DISABLED, notify this port immediately
        if (lastEvaluatedDecision && lastEvaluatedDecision.allow_patch === false) {
          try {
            port.postMessage({ source: 'flow-bridge-control', action: 'DISABLE' });
          } catch (_) {
            mainWorldPorts.delete(port);
          }
        }
      }
      return;
    }

    // Technical diagnostic messages from MAIN world
    if (event.data.source === 'flow-bridge-main-diag') {
      if (event.data.type === 'DIAG_UPDATE' || event.data.type === 'DIAG_SNAPSHOT_RESPONSE') {
        const payload = event.data.payload;
        if (payload && typeof payload === 'object') {
          storeTechnicalTelemetry(payload);
        }
      }
    }
  });

  // Listen for messages from popup
  if (chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
      if (request && request.type === 'GET_LIVE_DIAGNOSTICS') {
        const onSnapshot = function(event) {
          if (event.source === window && event.data && event.data.source === 'flow-bridge-main-diag' && event.data.type === 'DIAG_SNAPSHOT_RESPONSE') {
            window.removeEventListener('message', onSnapshot);
            clearTimeout(timeoutId);
            const validated = validateDiagnosticSchema(event.data.payload);
            if (validated) {
              cachedDiag = validated;
              sendResponse({ status: 'OK', data: validated });
            } else {
              sendResponse({ status: 'INVALID_DIAG_DISCARDED', data: null });
            }
          }
        };

        window.addEventListener('message', onSnapshot);
        const timeoutId = setTimeout(function() {
          window.removeEventListener('message', onSnapshot);
          if (cachedDiag) {
            sendResponse({ status: 'CACHED', data: cachedDiag });
          } else {
            sendResponse({ status: 'TIMEOUT', data: null });
          }
        }, 300);

        try {
          window.postMessage({ source: 'flow-bridge-isolated-diag', type: 'REQUEST_DIAG_SNAPSHOT' }, '*');
        } catch (e) {
          sendResponse({ status: 'ERROR', error: e.message, data: cachedDiag });
        }

        return true;
      }
    });
  }
})();
