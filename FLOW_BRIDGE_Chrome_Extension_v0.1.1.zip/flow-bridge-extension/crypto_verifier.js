/**
 * Flow Bridge Chrome Extension — Cryptographic Verifier & Security Authority (S1 Correction V3)
 * 
 * Verifies asymmetric Ed25519 digital signatures, monotonic revisions,
 * expiry validity with bounded last-known-good (LKG) offline grace,
 * semver compatibility, channel binding, and safe support URLs.
 * 
 * Cryptographic invariants:
 * - NO PRIVATE KEYS in client codebase or fixtures.
 * - extension-control-v1 is PERMANENTLY RETIRED (compromised).
 * - extension-control-v2 is PERMANENTLY RETIRED (preproduction ambiguity — never deploy).
 * - extension-control-v3 is ACTIVE production candidate key ID.
 * - Fail-closed on missing, expired-beyond-grace, or unverified control.
 */

'use strict';

(function(exports) {

  // Embedded Public Verification Keys (NO PRIVATE KEYS IN CLIENT)
  const TRUSTED_PUBLIC_KEYS = {
    'extension-control-v3': {
      algorithm: 'Ed25519',
      // Hex-encoded 32-byte raw public key for production authority
      rawHex: '20694987d7102286de1b89ba5c009d40f1e05550c980c567835367ba63186fbf',
      fingerprintSha256: '2052686e1a82e7e9f64e51ecd7ea18d5b4fb18464d5aaa3ead5364215d8fdbde',
      status: 'ACTIVE'
    },
    'extension-control-v2': {
      algorithm: 'Ed25519',
      rawHex: '5065d9c4f5fe1ae5069fef7c56e6133763d21d228879097e8462a7ccdd3eab51',
      fingerprintSha256: '7b1b83eb673c6b721097586f0cb3446d7c5a9048330738e30f38bfd9a3d49dda',
      status: 'RETIRED' // PREPRODUCTION_KEY_ID_AMBIGUITY — NEVER DEPLOY
    },
    'extension-control-v1': {
      algorithm: 'Ed25519',
      rawHex: '4374d2bf116c9cc9b346943328183e268e551ac3df18e60eb30857c94d3d87d5',
      fingerprintSha256: 'a68ef3ca02e5c8db9932fb993a46985a9df628f804fc9a9ca1ecbbcfbf6d1a9d',
      status: 'RETIRED' // PERMANENTLY COMPROMISED — NEVER TRUST FOR NEW CONTROL
    }
  };

  // Explicit security policy bounds
  const ACTIVE_OFFLINE_GRACE_SECONDS = 86400; // 24 hours bounded LKG grace
  const CLOCK_SKEW_TOLERANCE_SECONDS = 300;   // 5 minutes clock-skew tolerance
  const APPROVED_SUPPORT_URL = 'https://t.me/ITHRONIC';
  const ALLOWED_STATES = new Set(['ACTIVE', 'MAINTENANCE', 'UPDATE_REQUIRED', 'DISABLED']);
  const DEFAULT_CHANNEL = 'stable';

  /**
   * Deterministic JSON Canonicalization (lexicographically sorted UTF-16 keys, no whitespace)
   */
  function canonicalizePayload(obj) {
    if (obj === null || typeof obj !== 'object') {
      return JSON.stringify(obj);
    }
    if (Array.isArray(obj)) {
      return '[' + obj.map(canonicalizePayload).join(',') + ']';
    }
    const keys = Object.keys(obj).sort();
    const parts = keys.map(key => JSON.stringify(key) + ':' + canonicalizePayload(obj[key]));
    return '{' + parts.join(',') + '}';
  }

  /**
   * Hex string to Uint8Array converter
   */
  function hexToBytes(hex) {
    if (!hex || typeof hex !== 'string' || hex.length % 2 !== 0) return new Uint8Array(0);
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
      bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
    }
    return bytes;
  }

  /**
   * Base64 string to Uint8Array converter
   */
  function base64ToBytes(b64) {
    if (!b64 || typeof b64 !== 'string') return new Uint8Array(0);
    if (typeof atob === 'function') {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      return bytes;
    } else if (typeof Buffer !== 'undefined') {
      return new Uint8Array(Buffer.from(b64, 'base64'));
    }
    throw new Error('No base64 decoder available');
  }

  /**
   * Compare two semantic version strings (e.g. "0.1.10" > "0.1.9")
   * Returns: 1 if v1 > v2, -1 if v1 < v2, 0 if v1 === v2
   */
  function compareSemver(v1, v2) {
    if (typeof v1 !== 'string' || typeof v2 !== 'string') return 0;
    const p1 = v1.split('.').map(n => parseInt(n, 10) || 0);
    const p2 = v2.split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
      const num1 = p1[i] || 0;
      const num2 = p2[i] || 0;
      if (num1 > num2) return 1;
      if (num1 < num2) return -1;
    }
    return 0;
  }

  /**
   * Strict support URL validation: accepts ONLY the approved production destination
   */
  function validateSupportUrl(urlStr) {
    if (!urlStr || typeof urlStr !== 'string') return null;
    if (urlStr === APPROVED_SUPPORT_URL) {
      return APPROVED_SUPPORT_URL;
    }
    return null;
  }

  /**
   * Evaluate control gating policy on a verified manifest against installed version and time.
   * Unified policy used across Service Worker, Bootstrap, Popup, and Tests.
   */
  function evaluateControlPolicy(manifest, installedVersion = '0.1.0', nowMs = Date.now()) {
    if (!manifest || typeof manifest !== 'object') {
      return {
        allow_patch: false,
        state: 'CONTROL_UNAVAILABLE',
        reason: 'NO_VERIFIED_CONTROL',
        lkg_status: 'NONE'
      };
    }

    const state = manifest.state;

    // Explicit kill switch / maintenance / update required preservation
    if (state === 'DISABLED') {
      return {
        allow_patch: false,
        state: 'DISABLED',
        reason: 'REMOTE_KILL_SWITCH_ACTIVE',
        lkg_status: 'DISABLED_PERSISTED'
      };
    }

    if (state === 'MAINTENANCE') {
      return {
        allow_patch: false,
        state: 'MAINTENANCE',
        reason: 'REMOTE_MAINTENANCE_ACTIVE',
        lkg_status: 'MAINTENANCE_PERSISTED'
      };
    }

    if (state === 'UPDATE_REQUIRED') {
      return {
        allow_patch: false,
        state: 'UPDATE_REQUIRED',
        reason: 'MINIMUM_VERSION_UNMET',
        lkg_status: 'UPDATE_REQUIRED_PERSISTED'
      };
    }

    if (state === 'ACTIVE') {
      // Version compatibility check
      const minSupported = manifest.minimum_supported_version || '0.1.0';
      if (compareSemver(installedVersion, minSupported) < 0) {
        return {
          allow_patch: false,
          state: 'UPDATE_REQUIRED',
          reason: 'CLIENT_VERSION_OUTDATED',
          lkg_status: 'VERSION_BLOCKED'
        };
      }

      // Expiry & Bounded LKG Grace check
      const expiresAtMs = new Date(manifest.expires_at).getTime();
      if (isNaN(expiresAtMs)) {
        return {
          allow_patch: false,
          state: 'DISABLED',
          reason: 'INVALID_EXPIRY_TIMESTAMP',
          lkg_status: 'EXPIRED_INVALID'
        };
      }

      if (nowMs <= expiresAtMs) {
        return {
          allow_patch: true,
          state: 'ACTIVE',
          reason: 'CONTROL_ACTIVE_VALID',
          lkg_status: 'VALID'
        };
      }

      const graceLimitMs = expiresAtMs + (ACTIVE_OFFLINE_GRACE_SECONDS * 1000);
      if (nowMs <= graceLimitMs) {
        return {
          allow_patch: true,
          state: 'ACTIVE',
          reason: 'CONTROL_ACTIVE_WITHIN_OFFLINE_GRACE',
          lkg_status: 'ALLOW_CACHE_GRACE'
        };
      }

      // Bounded grace exceeded -> Fail closed
      return {
        allow_patch: false,
        state: 'DISABLED',
        reason: 'CONTROL_EXPIRED_BEYOND_GRACE',
        lkg_status: 'EXPIRED_BEYOND_GRACE'
      };
    }

    // Unknown state -> Fail closed
    return {
      allow_patch: false,
      state: 'DISABLED',
      reason: 'UNKNOWN_CONTROL_STATE',
      lkg_status: 'UNKNOWN_STATE_BLOCKED'
    };
  }

  /**
   * Verify Ed25519 digital signature over canonical payload using Web Crypto
   */
  async function verifySignature(envelope, trustedKeys = TRUSTED_PUBLIC_KEYS) {
    if (!envelope || typeof envelope !== 'object') {
      return { valid: false, error: 'INVALID_ENVELOPE_FORMAT' };
    }

    const { payload, signature, key_id, algorithm } = envelope;
    if (!payload || !signature || !key_id) {
      return { valid: false, error: 'MISSING_ENVELOPE_FIELDS' };
    }

    if (algorithm && algorithm !== 'Ed25519') {
      return { valid: false, error: 'UNSUPPORTED_ALGORITHM' };
    }

    const keyConfig = trustedKeys[key_id];
    if (!keyConfig || !keyConfig.rawHex) {
      return { valid: false, error: 'UNKNOWN_KEY_ID' };
    }

    if (keyConfig.status !== 'ACTIVE') {
      return { valid: false, error: 'KEY_RETIRED_OR_REVOKED', key_id: key_id, status: keyConfig.status };
    }

    try {
      const canonicalStr = canonicalizePayload(payload);
      const encoder = new TextEncoder();
      const messageBytes = encoder.encode(canonicalStr);

      const pubKeyBytes = hexToBytes(keyConfig.rawHex);
      const sigBytes = base64ToBytes(signature);

      if (pubKeyBytes.length !== 32) {
        return { valid: false, error: 'INVALID_PUBLIC_KEY_LENGTH' };
      }
      if (sigBytes.length !== 64) {
        return { valid: false, error: 'INVALID_SIGNATURE_LENGTH' };
      }

      const cryptoSubtle = (typeof crypto !== 'undefined' && crypto.subtle) ? crypto.subtle : require('crypto').webcrypto.subtle;

      const importedKey = await cryptoSubtle.importKey(
        'raw',
        pubKeyBytes,
        { name: 'Ed25519' },
        false,
        ['verify']
      );

      const isValid = await cryptoSubtle.verify(
        { name: 'Ed25519' },
        importedKey,
        sigBytes,
        messageBytes
      );

      if (!isValid) {
        return { valid: false, error: 'CONTROL_SIGNATURE_INVALID' };
      }

      return { valid: true, payload };
    } catch (err) {
      return { valid: false, error: 'VERIFICATION_EXCEPTION', detail: err.message };
    }
  }

  /**
   * Validate full manifest semantics against anti-rollback, channel, issued_at, expiry, and version policy
   */
  async function validateAndAdoptManifest(envelope, currentHighestRevision = 0, installedVersion = '0.1.0', nowMs = Date.now(), trustedKeys = TRUSTED_PUBLIC_KEYS, expectedChannel = DEFAULT_CHANNEL, cachedManifest = null) {
    const verifyResult = await verifySignature(envelope, trustedKeys);
    if (!verifyResult.valid) {
      return {
        adopted: false,
        rejection_reason: verifyResult.error,
        effective_decision: 'USE_CACHED'
      };
    }

    const manifest = verifyResult.payload;

    // 1. Schema check
    if (manifest.schema_version !== 1) {
      return { adopted: false, rejection_reason: 'UNSUPPORTED_SCHEMA_VERSION', effective_decision: 'USE_CACHED' };
    }

    // 2. Product identifier check
    if (manifest.product !== 'FLOW_BRIDGE_EXTENSION') {
      return { adopted: false, rejection_reason: 'PRODUCT_MISMATCH', effective_decision: 'USE_CACHED' };
    }

    // 3. Channel validation
    if (manifest.channel !== expectedChannel) {
      return {
        adopted: false,
        rejection_reason: 'CHANNEL_MISMATCH',
        manifest_channel: manifest.channel,
        expected_channel: expectedChannel,
        effective_decision: 'USE_CACHED'
      };
    }

    // 4. State enum check
    if (!ALLOWED_STATES.has(manifest.state)) {
      return { adopted: false, rejection_reason: 'UNKNOWN_CONTROL_STATE', effective_decision: 'USE_CACHED' };
    }

    // 5. issued_at Validation (reject future timestamps beyond clock skew tolerance)
    if (!manifest.issued_at || typeof manifest.issued_at !== 'string') {
      return { adopted: false, rejection_reason: 'MALFORMED_ISSUED_AT', effective_decision: 'USE_CACHED' };
    }
    const issuedAtMs = new Date(manifest.issued_at).getTime();
    if (isNaN(issuedAtMs)) {
      return { adopted: false, rejection_reason: 'MALFORMED_ISSUED_AT', effective_decision: 'USE_CACHED' };
    }
    if (issuedAtMs > (nowMs + (CLOCK_SKEW_TOLERANCE_SECONDS * 1000))) {
      return {
        adopted: false,
        rejection_reason: 'MANIFEST_ISSUED_IN_FUTURE',
        issued_at: manifest.issued_at,
        effective_decision: 'USE_CACHED'
      };
    }

    // 6. expires_at Validation (must be after issued_at)
    if (!manifest.expires_at || typeof manifest.expires_at !== 'string') {
      return { adopted: false, rejection_reason: 'INVALID_EXPIRY_TIMESTAMP', effective_decision: 'USE_CACHED' };
    }
    const expiresAtMs = new Date(manifest.expires_at).getTime();
    if (isNaN(expiresAtMs) || expiresAtMs <= issuedAtMs) {
      return { adopted: false, rejection_reason: 'INVALID_EXPIRY_TIMESTAMP', effective_decision: 'USE_CACHED' };
    }

    // 7. Anti-Rollback & Revision Monotonicity check
    const newRevision = parseInt(manifest.revision, 10) || 0;
    if (newRevision === currentHighestRevision) {
      if (cachedManifest) {
        const actualCached = (cachedManifest.verified_manifest) ? cachedManifest.verified_manifest : cachedManifest;
        if (actualCached && typeof actualCached === 'object') {
          const canonicalNew = canonicalizePayload(manifest);
          const canonicalCached = canonicalizePayload(actualCached);
          if (canonicalNew !== canonicalCached) {
            return {
              adopted: false,
              rejection_reason: 'SAME_REVISION_PAYLOAD_CONFLICT',
              manifest_revision: newRevision,
              current_revision: currentHighestRevision,
              effective_decision: 'USE_CACHED'
            };
          }
          return {
            adopted: false,
            rejection_reason: 'SAME_REVISION_NO_CHANGE',
            manifest_revision: newRevision,
            current_revision: currentHighestRevision,
            effective_decision: 'USE_CACHED'
          };
        }
      }
      return {
        adopted: false,
        rejection_reason: 'SAME_REVISION_UNTRUSTED_CACHE',
        manifest_revision: newRevision,
        current_revision: currentHighestRevision,
        effective_decision: 'USE_CACHED'
      };
    }
    if (newRevision < currentHighestRevision) {
      return {
        adopted: false,
        rejection_reason: 'CONTROL_ROLLBACK_REJECTED',
        manifest_revision: newRevision,
        current_revision: currentHighestRevision,
        effective_decision: 'USE_CACHED'
      };
    }

    // 8. Expiry check on adoption (manifest must not already be expired at adoption time)
    if ((expiresAtMs + (CLOCK_SKEW_TOLERANCE_SECONDS * 1000)) < nowMs) {
      return { adopted: false, rejection_reason: 'CONTROL_EXPIRED', effective_decision: 'USE_CACHED' };
    }

    // 9. Support URL hardening
    let safeSupportUrl = APPROVED_SUPPORT_URL;
    if (manifest.support_action && manifest.support_action.url) {
      safeSupportUrl = validateSupportUrl(manifest.support_action.url) || APPROVED_SUPPORT_URL;
    }

    const sanitizedManifest = Object.assign({}, manifest, {
      support_action: {
        type: (manifest.support_action && manifest.support_action.type) || 'TELEGRAM',
        url: safeSupportUrl
      }
    });

    // 10. Compute effective gating policy
    const policy = evaluateControlPolicy(sanitizedManifest, installedVersion, nowMs);

    return {
      adopted: true,
      new_highest_revision: newRevision,
      verified_manifest: sanitizedManifest,
      effective_state: policy.state,
      allow_patch: policy.allow_patch,
      lkg_status: policy.lkg_status,
      reason: policy.reason,
      verified_at: new Date(nowMs).toISOString()
    };
  }

  // Export functions and constants
  exports.canonicalizePayload = canonicalizePayload;
  exports.compareSemver = compareSemver;
  exports.validateSupportUrl = validateSupportUrl;
  exports.evaluateControlPolicy = evaluateControlPolicy;
  exports.verifySignature = verifySignature;
  exports.validateAndAdoptManifest = validateAndAdoptManifest;
  exports.TRUSTED_PUBLIC_KEYS = TRUSTED_PUBLIC_KEYS;
  exports.ACTIVE_OFFLINE_GRACE_SECONDS = ACTIVE_OFFLINE_GRACE_SECONDS;
  exports.CLOCK_SKEW_TOLERANCE_SECONDS = CLOCK_SKEW_TOLERANCE_SECONDS;
  exports.APPROVED_SUPPORT_URL = APPROVED_SUPPORT_URL;
  exports.DEFAULT_CHANNEL = DEFAULT_CHANNEL;

})(typeof exports !== 'undefined' ? exports : ((typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : self)).__FLOW_BRIDGE_CRYPTO__ = {}));
