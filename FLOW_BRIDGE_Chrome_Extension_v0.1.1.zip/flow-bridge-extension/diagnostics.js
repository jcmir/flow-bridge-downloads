/**
 * Flow Bridge Chrome Extension — Main-World Diagnostic State & Acceptance Recorder
 * Runs in MAIN world at document_start immediately before main_world.js.
 */

'use strict';

(function() {
  if (typeof window === 'undefined') return;

  let seqCounter = 0;
  const eventsList = [];
  const matchedFamilies = new Set();

  function recordEvent(name, data) {
    seqCounter++;
    const perfMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const isoTime = new Date().toISOString();
    const evt = {
      seq: seqCounter,
      event: name,
      timestamp: isoTime,
      perf_ms: perfMs,
      ready_state: typeof document !== 'undefined' ? document.readyState : 'unknown',
      ...(data || {})
    };
    eventsList.push(evt);
    notifyIsolatedBridge();
    return seqCounter;
  }

  function checkHookPersistence() {
    const origFetch = window.fetch;
    const isFetchWrapped = typeof origFetch === 'function' && (origFetch.__fb_wrapped === true || origFetch.__is_flow_bridge === true);
    const xhrTextDesc = Object.getOwnPropertyDescriptor(window.XMLHttpRequest ? window.XMLHttpRequest.prototype : {}, 'responseText');
    const xhrRespDesc = Object.getOwnPropertyDescriptor(window.XMLHttpRequest ? window.XMLHttpRequest.prototype : {}, 'response');
    const isXhrWrapped = Boolean((xhrTextDesc && xhrTextDesc.get && xhrTextDesc.get.__fb_wrapped === true) ||
                                 (xhrRespDesc && xhrRespDesc.get && xhrRespDesc.get.__fb_wrapped === true));
    return {
      fetch_hook_intact: Boolean(isFetchWrapped),
      xhr_hook_intact: Boolean(isXhrWrapped),
      check_timestamp: new Date().toISOString()
    };
  }

  // Detect navigation type and tab session identity
  let navType = 'navigate';
  try {
    const navEntries = performance.getEntriesByType('navigation');
    if (navEntries && navEntries[0] && navEntries[0].type) {
      navType = navEntries[0].type; // 'navigate' | 'reload' | 'back_forward'
    }
  } catch (_) {}

  let tabId = 'tab-' + Math.random().toString(36).substring(2, 10);
  let isFreshTab = true;
  try {
    if (window.sessionStorage) {
      const existingTabId = window.sessionStorage.getItem('__fb_tab_id__');
      if (existingTabId) {
        tabId = existingTabId;
        isFreshTab = false;
      } else {
        window.sessionStorage.setItem('__fb_tab_id__', tabId);
      }
    }
  } catch (_) {}

  const navigationId = 'nav_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

  function getSanitizedSnapshot() {
    return {
      extension_version: '0.1.0',
      current_target: 'flow.google.com',
      current_url: typeof location !== 'undefined' ? (location.origin + location.pathname + location.search) : '',
      current_url_path: typeof location !== 'undefined' ? location.pathname : '/',
      navigation_id: navigationId,
      nav_type: navType,
      tab_id: tabId,
      is_fresh_tab: isFreshTab,
      main_world_initialized: true,
      initial_ready_state: diagState.initial_ready_state,
      current_ready_state: typeof document !== 'undefined' ? document.readyState : 'unknown',
      bootstrap_timestamp: diagState.bootstrap_timestamp,
      fetch_hook_installed: diagState.fetch_patched,
      xhr_hook_installed: diagState.xhr_patched,
      first_call_observed: Boolean(diagState.sequence.first_call_observed),
      matched_response_count: diagState.counters.matched_response_count,
      transformation_applied_count: diagState.counters.transformation_applied_count,
      signout_prevented_count: diagState.counters.signout_prevented,
      batchexecute_patched_count: diagState.counters.batchexecute_patched,
      availability_patched_count: diagState.counters.availability_patched,
      protobuf_rpc_patched_count: diagState.counters.protobuf_rpc_patched,
      fetch_intercepted_count: diagState.counters.fetch_intercepted,
      xhr_intercepted_count: diagState.counters.xhr_intercepted,
      matched_families: Array.from(matchedFamilies),
      ordering_sequence: eventsList.slice(),
      hook_persistence: checkHookPersistence(),
      last_navigation_timestamp: diagState.bootstrap_timestamp,
      last_update_timestamp: new Date().toISOString()
    };
  }

  function notifyIsolatedBridge() {
    try {
      if (typeof window.postMessage === 'function') {
        window.postMessage({
          source: 'flow-bridge-main-diag',
          type: 'DIAG_UPDATE',
          payload: getSanitizedSnapshot()
        }, '*');
      }
    } catch (_) {}
  }

  // Listen for requests from ISOLATED world
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('message', function(event) {
      if (event.source !== window || !event.data || event.data.source !== 'flow-bridge-isolated-diag') {
        return;
      }
      if (event.data.type === 'REQUEST_DIAG_SNAPSHOT') {
        try {
          if (typeof window.postMessage === 'function') {
            window.postMessage({
              source: 'flow-bridge-main-diag',
              type: 'DIAG_SNAPSHOT_RESPONSE',
              payload: getSanitizedSnapshot()
            }, '*');
          }
        } catch (_) {}
      }
    });
  }

  const initNow = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const initIso = new Date().toISOString();

  const diagState = {
    version: '0.1.0',
    target: 'https://flow.google.com/*',
    bootstrap_timestamp: initIso,
    bootstrap_perf_ms: initNow,
    initial_ready_state: typeof document !== 'undefined' ? document.readyState : 'unknown',
    navigation_id: navigationId,
    nav_type: navType,
    tab_id: tabId,
    is_fresh_tab: isFreshTab,
    fetch_patched: false,
    xhr_patched: false,
    installed: false,
    installation_completed_ms: null,
    sequence: {
      main_bootstrap: null,
      xhr_wrapper_installed: null,
      fetch_wrapper_installed: null,
      first_call_observed: null,
      first_transformation_applied: null
    },
    timestamps: {
      bootstrap: initIso,
      first_fetch_intercept: null,
      first_xhr_intercept: null,
      first_transformation: null
    },
    counters: {
      fetch_intercepted: 0,
      xhr_intercepted: 0,
      matched_response_count: 0,
      transformation_applied_count: 0,
      batchexecute_patched: 0,
      availability_patched: 0,
      signout_prevented: 0,
      protobuf_rpc_patched: 0
    },
    matchedFamilies: matchedFamilies,
    events: eventsList,
    recordEvent: recordEvent,
    checkHookPersistence: checkHookPersistence,
    getSanitizedSnapshot: getSanitizedSnapshot,
    notifyUpdate: notifyIsolatedBridge
  };

  diagState.sequence.main_bootstrap = recordEvent('MAIN_BOOTSTRAP_INIT', { nav_type: navType, tab_id: tabId });
  window.__FLOW_BRIDGE_DIAGNOSTICS__ = diagState;

  console.log('[Flow Bridge Extension] Diagnostics & Acceptance Recorder initialized at document_start (nav=' + navType + ', tab=' + tabId + ')');
})();
