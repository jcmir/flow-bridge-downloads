/**
 * Flow Bridge Chrome Extension — Main World RESPONSE_ONLY Patch (S1 Correction V3)
 * 
 * Semantics derived faithfully from canonical frozen reference:
 * reference/extracted_response_only.js (SHA256: CED5ED926565AB77161D76D3E9DB1483154E2EC3EA28EBE5084235C8253A49C6)
 * 
 * Gating Invariants:
 * 1. Neutral wrappers installed synchronously at document_start (no network requests escape).
 * 2. Transformations occur ONLY when verified local control gate evaluates to allow_patch=true (ACTIVE).
 * 3. When gate evaluates to allow_patch=false (DISABLED, MAINTENANCE, UPDATE_REQUIRED, UNAVAILABLE),
 *    all responses pass through 100% unmodified and route recovery is blocked.
 */

(function() {
    'use strict';

    const win = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
    const diag = win.__FLOW_BRIDGE_DIAGNOSTICS__ || null;

    console.log('[Flow Unlocker RESPONSE_ONLY] 🚀 Initialized on:', location.href);

    // Safeguard: Redirect old dummy test project ID to root
    if (location.href.includes('3d3ec587-30a3-488a-a3b7-03fae3d45417')) {
        console.log('[Flow Unlocker] Detected dummy project URL, redirecting to Flow root...');
        location.replace('https://flow.google.com/');
        return;
    }

    // Gating state management (S3 Correction V2 Multi-Channel Irrevocable Gate)
    let isPermanentlyDisabled = false;
    let controlPort = null;

    function applyDisableSignal(sourceType) {
        if (isPermanentlyDisabled) return; // Idempotent one-way latch
        isPermanentlyDisabled = true;
        console.warn(`[Flow Bridge Main World] Received authentic DISABLE signal (${sourceType}). Transformations permanently disabled.`);
        if (diag && typeof diag.recordEvent === 'function') {
            diag.recordEvent('CONTROL_GATE_STATE_APPLIED', {
                state: 'DISABLED',
                allow_patch: false,
                reason: 'AUTHENTIC_KILL_SWITCH_TRIGGERED',
                source: sourceType
            });
        }
    }

    // Direct out-of-band hook for privileged Chrome API (executeScript from Service Worker)
    // Protected against tampering or reassignment
    try {
        Object.defineProperty(win, '__FLOW_BRIDGE_FORCE_DISABLE__', {
            value: function() {
                applyDisableSignal('SERVICE_WORKER_DIRECT_EXECUTION');
                try {
                    Object.defineProperty(win, '__FLOW_BRIDGE_FORCE_DISABLE_LATCH__', {
                        value: true,
                        writable: false,
                        configurable: false
                    });
                } catch (_) {}
                return {
                    applied: true,
                    state: 'DISABLED',
                    permanentlyDisabled: isPermanentlyDisabled,
                    timestamp: new Date().toISOString()
                };
            },
            writable: false,
            configurable: false
        });
    } catch (_) {
        win.__FLOW_BRIDGE_FORCE_DISABLE__ = function() {
            applyDisableSignal('SERVICE_WORKER_DIRECT_EXECUTION');
            win.__FLOW_BRIDGE_FORCE_DISABLE_LATCH__ = true;
            return {
                applied: true,
                state: 'DISABLED',
                permanentlyDisabled: isPermanentlyDisabled,
                timestamp: new Date().toISOString()
            };
        };
    }

    // Observe DOM dataset for fallback disable signal
    if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined') {
        try {
            const domObserver = new MutationObserver(function() {
                if (document.documentElement && document.documentElement.dataset &&
                    (document.documentElement.dataset.flowBridgeDisabled === 'true' || document.documentElement.dataset.flowBridgeState === 'DISABLED')) {
                    applyDisableSignal('DOM_DATASET_OBSERVER');
                }
            });
            if (document.documentElement) {
                domObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-flow-bridge-disabled', 'data-flow-bridge-state'] });
            }
        } catch (_) {}
    }

    // Establish point-to-point MessagePort with isolated bootstrap
    if (typeof MessageChannel !== 'undefined') {
        try {
            const controlChannel = new MessageChannel();
            controlPort = controlChannel.port1;
            controlPort.onmessage = function(event) {
                if (event && event.data && event.data.action === 'DISABLE') {
                    applyDisableSignal('PRIVATE_MESSAGE_PORT');
                }
            };
            // Transfer port2 to isolated bootstrap
            win.postMessage({ source: 'flow-bridge-main-handshake', type: 'PORT_OFFER' }, '*', [controlChannel.port2]);
        } catch (_) {}
    }

    // Redundant window broadcast listener:
    // Any DISABLE signal from ANY channel triggers the one-way latch.
    // An in-page script can at most cause self-disable (fail-safe/DoS safe).
    // NO CHANNEL EVER ACCEPTS AN "ENABLE" OR "ALLOW" SIGNAL.
    win.addEventListener('message', function(event) {
        if (event && event.data && event.data.source === 'flow-bridge-control' && event.data.action === 'DISABLE') {
            applyDisableSignal('WINDOW_BROADCAST_CHANNEL');
        }
    });

    function isUnsupportedCountryRoute() {
        return (
            location.origin === 'https://flow.google.com' &&
            (
                location.pathname === '/unsupported-country' ||
                location.pathname === '/unsupported-country/'
            )
        );
    }

    function executeRouteRecovery() {
        console.log('[Flow Bridge] Triggering /unsupported-country route recovery to root...');
        if (diag && typeof diag.recordEvent === 'function') {
            diag.recordEvent('UNSUPPORTED_COUNTRY_ROUTE_RECOVERY_TRIGGERED', {
                source_path: location.pathname,
                destination_path: '/'
            });
        }
        location.replace('https://flow.google.com/');
    }

    function shouldTransformSync() {
        if (isPermanentlyDisabled) return false;
        if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset && document.documentElement.dataset.flowBridgeDisabled === 'true') {
            isPermanentlyDisabled = true;
            return false;
        }
        return true;
    }

    // Route Recovery at document_start if route is /unsupported-country
    if (isUnsupportedCountryRoute() && shouldTransformSync()) {
        executeRouteRecovery();
    }

    async function shouldTransformAsync() {
        return shouldTransformSync();
    }

    // 2. Native Closure-compatible Stream & Batch Patcher
    const TARGET_RPCS = ['cPZSdc', 'KV2T2d', 'rThb8d', 'cO7JOb', 'md9xJf'];

    function patchProtobufJson(str, rpcid) {
        try {
            let inner = JSON.parse(str);
            if (Array.isArray(inner)) {
                if (rpcid === 'cPZSdc') {
                    // FLOW_APP_CONFIG: field 31 (country supported), field 32 (age supported)
                    while (inner.length < 32) inner.push(null);
                    inner[30] = 1; // is_country_supported = true
                    inner[31] = 1; // is_age_supported = true
                    console.log('[Flow Unlocker] ✅ Patched cPZSdc (country=1, age=1)');
                    if (diag) {
                        diag.counters.protobuf_rpc_patched++;
                        diag.counters.matched_response_count++;
                        diag.counters.transformation_applied_count++;
                        if (diag.matchedFamilies) {
                            diag.matchedFamilies.add('batchexecute');
                            diag.matchedFamilies.add('protobuf');
                        }
                        if (!diag.sequence.first_transformation_applied) {
                            diag.sequence.first_transformation_applied = diag.recordEvent('FIRST_TRANSFORMATION_APPLIED', { rpcid: 'cPZSdc', family: 'batchexecute' });
                        }
                        if (!diag.timestamps.first_transformation) {
                            diag.timestamps.first_transformation = new Date().toISOString();
                        }
                        diag.notifyUpdate();
                    }
                } else if (TARGET_RPCS.includes(rpcid)) {
                    // CheckToolAvailability / CheckFlowAvailability / CheckAppAvailability
                    if (inner.length === 0) inner.push(1);
                    else inner[0] = 1; // field 1 = AVAILABLE / TIER_ONE
                    console.log(`[Flow Unlocker] ✅ Patched ${rpcid} (status=1 AVAILABLE)`);
                    if (diag) {
                        diag.counters.protobuf_rpc_patched++;
                        diag.counters.matched_response_count++;
                        diag.counters.transformation_applied_count++;
                        if (diag.matchedFamilies) {
                            diag.matchedFamilies.add('batchexecute');
                            diag.matchedFamilies.add('protobuf');
                        }
                        if (!diag.sequence.first_transformation_applied) {
                            diag.sequence.first_transformation_applied = diag.recordEvent('FIRST_TRANSFORMATION_APPLIED', { rpcid, family: 'batchexecute' });
                        }
                        if (!diag.timestamps.first_transformation) {
                            diag.timestamps.first_transformation = new Date().toISOString();
                        }
                        diag.notifyUpdate();
                    }
                }
                return JSON.stringify(inner);
            }
        } catch(e) {}
        return str;
    }

    function patchGoogleStream(raw) {
        if (!raw || typeof raw !== 'string') return raw;
        if (!TARGET_RPCS.some(id => raw.includes(id))) return raw;

        // Check Google prefix
        let headerEnd = raw.indexOf(")]}'\n\n");
        let ua = 0;
        let prefix = "";
        if (headerEnd >= 0) {
            ua = headerEnd + 6;
            prefix = raw.slice(0, ua);
        } else {
            headerEnd = raw.indexOf("\n\n");
            if (headerEnd >= 0) {
                ua = headerEnd + 2;
                prefix = raw.slice(0, ua);
            }
        }

        // Strategy A: Try parsing as standard JSON batch first
        let body = raw.slice(ua);
        try {
            let data = JSON.parse(body);
            if (Array.isArray(data)) {
                let modified = false;
                for (let item of data) {
                    if (Array.isArray(item) && TARGET_RPCS.includes(item[1]) && typeof item[2] === 'string') {
                        item[2] = patchProtobufJson(item[2], item[1]);
                        modified = true;
                    }
                }
                if (modified) {
                    if (diag) {
                        diag.counters.batchexecute_patched++;
                        if (diag.matchedFamilies) diag.matchedFamilies.add('batchexecute');
                        diag.notifyUpdate();
                    }
                    return prefix + JSON.stringify(data);
                }
            }
        } catch(_) {}

        // Strategy B: Native Closure MFa stream parser & rebuilder
        let out = prefix;
        let pos = ua;
        let anyModified = false;

        while (pos < raw.length) {
            let nextNl = raw.indexOf("\n", pos);
            if (nextNl === -1) {
                out += raw.slice(pos);
                break;
            }
            let lenStr = raw.substring(pos, nextNl);
            let len = Number(lenStr);
            if (isNaN(len) || nextNl + len > raw.length) {
                out += raw.slice(pos);
                break;
            }

            let chunkWithNl = raw.substr(nextNl, len); // starts with \n
            let chunkJson = chunkWithNl.slice(1);      // strip leading \n
            try {
                let chunk = JSON.parse(chunkJson);
                let chunkModified = false;
                for (let item of chunk) {
                    if (Array.isArray(item) && TARGET_RPCS.includes(item[1]) && typeof item[2] === 'string') {
                        item[2] = patchProtobufJson(item[2], item[1]);
                        chunkModified = true;
                        anyModified = true;
                    }
                }
                if (chunkModified) {
                    let newChunkJson = JSON.stringify(chunk);
                    let newLen = 1 + newChunkJson.length; // 1 for leading \n required by Closure!
                    out += String(newLen) + '\n' + newChunkJson;
                } else {
                    out += lenStr + chunkWithNl;
                }
            } catch(err) {
                out += lenStr + chunkWithNl;
            }
            pos = nextNl + len;
        }

        if (anyModified && diag) {
            diag.counters.batchexecute_patched++;
            if (diag.matchedFamilies) diag.matchedFamilies.add('batchexecute');
            diag.notifyUpdate();
        }

        return anyModified ? out : raw;
    }

    // 3. Recursive JSON patcher for Next.js tRPC & REST endpoints (labs.google)
    function patchDeepJson(data) {
        if (!data || typeof data !== 'object') return data;
        if (Array.isArray(data)) {
            for (let i = 0; i < data.length; i++) {
                data[i] = patchDeepJson(data[i]);
            }
        } else {
            for (let k of Object.keys(data)) {
                if (k === 'availabilityState') {
                    if (data[k] !== 'AVAILABLE') {
                        console.log(`[Flow Unlocker] ✅ Patched availabilityState: "${data[k]}" -> "AVAILABLE"`);
                        data[k] = 'AVAILABLE';
                        if (diag) {
                            diag.counters.availability_patched++;
                            diag.counters.matched_response_count++;
                            diag.counters.transformation_applied_count++;
                            if (diag.matchedFamilies) diag.matchedFamilies.add('availability');
                            if (!diag.sequence.first_transformation_applied) {
                                diag.sequence.first_transformation_applied = diag.recordEvent('FIRST_TRANSFORMATION_APPLIED', { field: 'availabilityState', family: 'availability' });
                            }
                            if (!diag.timestamps.first_transformation) {
                                diag.timestamps.first_transformation = new Date().toISOString();
                            }
                            diag.notifyUpdate();
                        }
                    }
                } else if (k === 'isCountrySupported' || k === 'is_country_supported') {
                    data[k] = true;
                    if (diag) {
                        diag.counters.availability_patched++;
                        diag.counters.matched_response_count++;
                        diag.counters.transformation_applied_count++;
                        if (diag.matchedFamilies) diag.matchedFamilies.add('availability');
                        diag.notifyUpdate();
                    }
                } else if (k === 'isAgeSupported' || k === 'is_age_supported') {
                    data[k] = true;
                    if (diag) {
                        diag.counters.availability_patched++;
                        diag.counters.matched_response_count++;
                        diag.counters.transformation_applied_count++;
                        if (diag.matchedFamilies) diag.matchedFamilies.add('availability');
                        diag.notifyUpdate();
                    }
                } else if (typeof data[k] === 'object') {
                    data[k] = patchDeepJson(data[k]);
                }
            }
        }
        return data;
    }

    // 4. Hook XMLHttpRequest (Angular flow.google.com batchexecute)
    try {
        const XHR = win.XMLHttpRequest;
        if (XHR && XHR.prototype) {
            const origTextDesc = Object.getOwnPropertyDescriptor(XHR.prototype, 'responseText');
            const origRespDesc = Object.getOwnPropertyDescriptor(XHR.prototype, 'response');

            if (origTextDesc && origTextDesc.get) {
                const getResponseText = function() {
                    try {
                        if (this.responseType && this.responseType !== 'text') {
                            return origTextDesc.get.call(this);
                        }
                        const raw = origTextDesc.get.call(this);
                        if (diag) {
                            if (!diag.sequence.first_call_observed) {
                                diag.sequence.first_call_observed = diag.recordEvent('FIRST_XHR_CALL_OBSERVED');
                            }
                            if (!diag.timestamps.first_xhr_intercept) {
                                diag.timestamps.first_xhr_intercept = new Date().toISOString();
                            }
                            diag.counters.xhr_intercepted++;
                            diag.notifyUpdate();
                        }
                        // GATED: Only transform if security gate allows
                        if (!shouldTransformSync()) {
                            return raw;
                        }
                        return patchGoogleStream(raw);
                    } catch(e) {
                        try { return origTextDesc.get.call(this); } catch(_) { return ''; }
                    }
                };
                getResponseText.__fb_wrapped = true;

                Object.defineProperty(XHR.prototype, 'responseText', {
                    get: getResponseText,
                    configurable: true
                });
            }

            if (origRespDesc && origRespDesc.get) {
                const getResponse = function() {
                    try {
                        if (this.responseType && this.responseType !== 'text' && this.responseType !== '') {
                            return origRespDesc.get.call(this);
                        }
                        const raw = origRespDesc.get.call(this);
                        if (typeof raw === 'string') {
                            if (diag) {
                                if (!diag.sequence.first_call_observed) {
                                    diag.sequence.first_call_observed = diag.recordEvent('FIRST_XHR_CALL_OBSERVED');
                                }
                                if (!diag.timestamps.first_xhr_intercept) {
                                    diag.timestamps.first_xhr_intercept = new Date().toISOString();
                                }
                                diag.counters.xhr_intercepted++;
                                diag.notifyUpdate();
                            }
                            // GATED: Only transform if security gate allows
                            if (!shouldTransformSync()) {
                                return raw;
                            }
                            return patchGoogleStream(raw);
                        }
                        return raw;
                    } catch(e) {
                        try { return origRespDesc.get.call(this); } catch(_) { return null; }
                    }
                };
                getResponse.__fb_wrapped = true;

                Object.defineProperty(XHR.prototype, 'response', {
                    get: getResponse,
                    configurable: true
                });
            }

            if (diag) {
                diag.xhr_patched = true;
                diag.sequence.xhr_wrapper_installed = diag.recordEvent('XHR_WRAPPER_INSTALLED');
            }
        }
    } catch(e) {
        console.error('[Flow Unlocker] XHR hook error:', e);
    }

    // 5. Hook window.fetch (Next.js labs.google tRPC & Google AI API)
    try {
        const origFetch = win.fetch;
        const fbFetch = async function(...args) {
            if (diag) {
                if (!diag.sequence.first_call_observed) {
                    diag.sequence.first_call_observed = diag.recordEvent('FIRST_FETCH_CALL_OBSERVED');
                }
                if (!diag.timestamps.first_fetch_intercept) {
                    diag.timestamps.first_fetch_intercept = new Date().toISOString();
                }
                diag.counters.fetch_intercepted++;
                diag.notifyUpdate();
            }
            const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');

            // Gated transform decision
            const allowTransform = await shouldTransformAsync();

            // Prevent NextAuth signOut trigger (only when gate is active)
            if (url.includes('api/auth/signout')) {
                if (allowTransform) {
                    console.warn('[Flow Unlocker] 🚫 Prevented NextAuth signOut call');
                    if (diag) {
                        diag.counters.signout_prevented++;
                        diag.notifyUpdate();
                    }
                    return new Response(JSON.stringify({ url: location.href }), {
                        status: 200,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }
            }

            const res = await origFetch.apply(this, args);

            if (!allowTransform) {
                return res;
            }

            // Batchexecute over fetch
            if (url.includes('batchexecute')) {
                try {
                    const raw = await res.text();
                    const patched = patchGoogleStream(raw);
                    const headers = new Headers(res.headers);
                    headers.delete('content-length');
                    return new Response(patched, {
                        status: res.status,
                        statusText: res.statusText,
                        headers: headers
                    });
                } catch(e) {
                    return res;
                }
            }

            // Only inspect JSON responses for availability endpoints
            if (url.includes('fetchToolAvailability') ||
                url.includes('checkAppAvailability') ||
                url.includes('trpc/general.')) {
                try {
                    const text = await res.text();
                    let headers = new Headers(res.headers);
                    headers.delete('content-length');
                    try {
                        const data = JSON.parse(text);
                        patchDeepJson(data);
                        return new Response(JSON.stringify(data), {
                            status: 200,
                            statusText: 'OK',
                            headers: headers
                        });
                    } catch(err) {
                        return new Response(text, {
                            status: res.status,
                            statusText: res.statusText,
                            headers: headers
                        });
                    }
                } catch(e) {
                    return res;
                }
            }

            return res;
        };
        fbFetch.__fb_wrapped = true;
        fbFetch.__is_flow_bridge = true;
        win.fetch = fbFetch;

        if (diag) {
            diag.fetch_patched = true;
            diag.sequence.fetch_wrapper_installed = diag.recordEvent('FETCH_WRAPPER_INSTALLED');
        }
    } catch(e) {
        console.error('[Flow Unlocker] Fetch hook error:', e);
    }

    if (diag) {
        diag.installed = true;
        diag.installation_completed_ms = typeof performance !== 'undefined' ? performance.now() : Date.now();
        diag.recordEvent('MAIN_INSTALLATION_COMPLETE');
        diag.notifyUpdate();
    }
})();
