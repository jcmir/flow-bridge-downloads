/**
 * Flow Bridge Chrome Extension — Popup Controller (Consumer UX V1)
 * Displays friendly consumer status, Telegram/Donation support, and collapsible technical diagnostics.
 */

'use strict';

let currentDiagData = null;
let currentControlData = null;

function renderControlState(control, policy) {
  currentControlData = control;
  const statusHero = document.getElementById('statusHero');
  const heroIcon = document.getElementById('heroIcon');
  const heroTitle = document.getElementById('heroTitle');
  const heroDesc = document.getElementById('heroDesc');

  const secSigState = document.getElementById('secSigState');
  const secRevision = document.getElementById('secRevision');
  const secKeyId = document.getElementById('secKeyId');
  const secSource = document.getElementById('secSource');
  const secGate = document.getElementById('secGate');

  if (!control || !control.verified_manifest || (policy && policy.state === 'CONTROL_UNAVAILABLE')) {
    if (statusHero) statusHero.className = 'status-hero unavailable';
    if (heroIcon) heroIcon.textContent = '⚪';
    if (heroTitle) heroTitle.textContent = 'Не удалось проверить состояние';
    if (heroDesc) heroDesc.textContent = 'Связь со службой расширения временно недоступна. Попробуйте обновить статус через несколько секунд.';

    if (secRevision) secRevision.textContent = '—';
    if (secKeyId) secKeyId.textContent = '—';
    if (secSource) secSource.textContent = 'NONE';
    if (secSigState) {
      secSigState.textContent = 'UNVERIFIED';
      secSigState.className = 'val fail';
    }
    if (secGate) {
      secGate.textContent = 'BLOCK';
      secGate.className = 'val fail';
    }
    return;
  }

  const manifest = control.verified_manifest || {};
  const effectiveState = (policy && policy.state) || control.effective_state || manifest.state || 'ACTIVE';
  const allowPatch = (policy && typeof policy.allow_patch === 'boolean') ? policy.allow_patch : (control.allow_patch !== false && effectiveState === 'ACTIVE');

  if (secRevision) secRevision.textContent = control.new_highest_revision || manifest.revision || 1;
  if (secKeyId) secKeyId.textContent = manifest.key_id || 'extension-control-v3';
  if (secSource) secSource.textContent = control.source || 'LIVE_SIGNED';
  if (secSigState) {
    secSigState.textContent = 'VALID';
    secSigState.className = 'val pass';
  }

  if (secGate) {
    secGate.textContent = allowPatch ? 'ALLOW' : 'BLOCK';
    secGate.className = 'val ' + (allowPatch ? 'pass' : 'fail');
  }

  if (effectiveState === 'ACTIVE') {
    if (statusHero) statusHero.className = 'status-hero active';
    if (heroIcon) heroIcon.textContent = '🟢';
    if (heroTitle) heroTitle.textContent = 'FLOW BRIDGE активен';
    if (heroDesc) heroDesc.textContent = 'Мост подключён к Google Flow. Если вкладка Flow была открыта ранее, нажмите кнопку «Обновить страницу» или перезагрузите вкладку.';
  } else if (effectiveState === 'DISABLED' || effectiveState === 'MAINTENANCE') {
    if (statusHero) statusHero.className = 'status-hero disabled';
    if (heroIcon) heroIcon.textContent = '🟠';
    if (heroTitle) heroTitle.textContent = 'FLOW BRIDGE · Техработы';
    if (heroDesc) heroDesc.innerHTML = 'Сейчас идёт плановое обслуживание программы.<br>В ближайшее время работа восстановится.<br>Актуальная информация — в Telegram-группе.';
  } else if (effectiveState === 'UPDATE_REQUIRED') {
    if (statusHero) statusHero.className = 'status-hero update-required';
    if (heroIcon) heroIcon.textContent = '⚠️';
    if (heroTitle) heroTitle.textContent = 'Требуется обновление';
    const minVer = manifest.minimum_supported_version || '0.1.1+';
    if (heroDesc) heroDesc.textContent = 'Установленная версия устарела (требуется v' + minVer + '). Проверьте актуальную версию в Telegram-канале.';
  }
}

function renderDiagnostics(data) {
  currentDiagData = data;
  const statusDot = document.getElementById('statusDot');
  const targetStatusText = document.getElementById('targetStatusText');
  const mainWorldVal = document.getElementById('mainWorldVal');
  const fetchHookVal = document.getElementById('fetchHookVal');
  const xhrHookVal = document.getElementById('xhrHookVal');
  const hookPersistenceVal = document.getElementById('hookPersistenceVal');
  const transformationsCount = document.getElementById('transformationsCount');
  const matchedResponsesCount = document.getElementById('matchedResponsesCount');
  const interceptedCount = document.getElementById('interceptedCount');
  const batchCount = document.getElementById('batchCount');

  if (!data) {
    if (statusDot) statusDot.className = 'status-dot inactive';
    if (targetStatusText) targetStatusText.textContent = 'Target: flow.google.com не открыт в этой вкладке';
    if (mainWorldVal) {
      mainWorldVal.textContent = 'NOT LOADED';
      mainWorldVal.className = 'val fail';
    }
    if (fetchHookVal) fetchHookVal.textContent = 'OFF';
    if (xhrHookVal) xhrHookVal.textContent = 'OFF';
    if (hookPersistenceVal) hookPersistenceVal.textContent = 'OFF';
    return;
  }

  if (statusDot) statusDot.className = 'status-dot active';
  if (targetStatusText) targetStatusText.textContent = 'Target: ' + (data.current_target || 'flow.google.com') + ' (ACTIVE)';

  if (mainWorldVal) {
    mainWorldVal.textContent = data.main_world_initialized ? 'ACTIVE' : 'INACTIVE';
    mainWorldVal.className = 'val ' + (data.main_world_initialized ? 'pass' : 'fail');
  }

  if (fetchHookVal) {
    fetchHookVal.textContent = data.fetch_hook_installed ? 'INSTALLED' : 'OFF';
    fetchHookVal.className = 'val ' + (data.fetch_hook_installed ? 'pass' : 'fail');
  }

  if (xhrHookVal) {
    xhrHookVal.textContent = data.xhr_hook_installed ? 'INSTALLED' : 'OFF';
    xhrHookVal.className = 'val ' + (data.xhr_hook_installed ? 'pass' : 'fail');
  }

  const hookIntact = data.hook_persistence && data.hook_persistence.fetch_hook_intact && data.hook_persistence.xhr_hook_intact;
  if (hookPersistenceVal) {
    hookPersistenceVal.textContent = hookIntact ? 'INTACT (100%)' : 'DEGRADED';
    hookPersistenceVal.className = 'val ' + (hookIntact ? 'pass' : 'fail');
  }

  if (transformationsCount) transformationsCount.textContent = data.transformation_applied_count || 0;
  if (matchedResponsesCount) matchedResponsesCount.textContent = data.matched_response_count || 0;
  if (interceptedCount) interceptedCount.textContent = (data.fetch_intercepted_count || 0) + (data.xhr_intercepted_count || 0);
  if (batchCount) batchCount.textContent = data.batchexecute_patched_count || 0;
}

function fetchAllState() {
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'GET_CONTROL_STATUS' }, function(response) {
      if (chrome.runtime.lastError || !response || response.status !== 'OK') {
        renderControlState(null, { state: 'CONTROL_UNAVAILABLE', allow_patch: false });
      } else {
        renderControlState(response.cached_record, response.policy);
      }
    });
  } else {
    renderControlState(null, { state: 'CONTROL_UNAVAILABLE', allow_patch: false });
  }

  if (chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['flow_bridge_latest_diag'], function(items) {
      if (items && items.flow_bridge_latest_diag) {
        renderDiagnostics(items.flow_bridge_latest_diag);
      }
    });
  }

  if (chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_LIVE_DIAGNOSTICS' }, function(response) {
          if (!chrome.runtime.lastError && response && response.data) {
            renderDiagnostics(response.data);
          }
        });
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', function() {
  fetchAllState();
  const pollInterval = setInterval(fetchAllState, 1000);
  window.addEventListener('unload', function() {
    clearInterval(pollInterval);
  });

  const btnRefresh = document.getElementById('btnRefresh');
  if (btnRefresh) {
    btnRefresh.addEventListener('click', function() {
      btnRefresh.textContent = '🔄 Checking…';
      btnRefresh.disabled = true;

      chrome.runtime.sendMessage({ type: 'REFRESH_REMOTE_CONTROL' }, function() {
        setTimeout(function() {
          btnRefresh.textContent = '🔄 Check Status';
          btnRefresh.disabled = false;
          fetchAllState();
        }, 500);
      });
    });
  }

  const btnCopy = document.getElementById('btnCopy');
  if (btnCopy) {
    btnCopy.addEventListener('click', function() {
      chrome.storage.local.get([
        'last_fetch_attempt', 'last_fetch_success', 'last_adopted_revision',
        'last_enforced_revision', 'last_enforcement_result', 'last_error_code', 'highest_revision'
      ], function(extra) {
        const fullPayload = {
          timestamp: new Date().toISOString(),
          extension_version: (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '0.1.0',
          control: currentControlData,
          diagnostics: currentDiagData,
          sync_status: extra || {}
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(JSON.stringify(fullPayload, null, 2)).then(function() {
            const orig = btnCopy.textContent;
            btnCopy.textContent = '✔ Copied!';
            setTimeout(function() { btnCopy.textContent = orig; }, 1500);
          });
        }
      });
    });
  }

  const btnExport = document.getElementById('btnExport');
  if (btnExport) {
    btnExport.addEventListener('click', function() {
      chrome.storage.local.get([
        'last_fetch_attempt', 'last_fetch_success', 'last_adopted_revision',
        'last_enforced_revision', 'last_enforcement_result', 'last_error_code', 'highest_revision'
      ], function(extra) {
        const fullPayload = {
          evidence_type: 'FLOW_BRIDGE_CLIENT_DIAGNOSTIC_SNAPSHOT',
          timestamp: new Date().toISOString(),
          extension_version: (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '0.1.0',
          control: currentControlData,
          diagnostics: currentDiagData,
          sync_status: extra || {}
        };
        const blob = new Blob([JSON.stringify(fullPayload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'flow_bridge_diagnostics_' + Date.now() + '.json';
        a.click();
        URL.revokeObjectURL(url);
      });
    });
  }

  // Telegram support button handler
  const btnTelegram = document.getElementById('btnTelegram');
  if (btnTelegram) {
    btnTelegram.addEventListener('click', function(e) {
      if (chrome.tabs && chrome.tabs.create) {
        e.preventDefault();
        chrome.tabs.create({ url: 'https://t.me/ITHRONIC' });
      }
    });
  }

  // CloudTips donation button handler
  const btnDonation = document.getElementById('btnDonation');
  if (btnDonation) {
    btnDonation.addEventListener('click', function(e) {
      if (chrome.tabs && chrome.tabs.create) {
        e.preventDefault();
        chrome.tabs.create({ url: 'https://pay.cloudtips.ru/p/9e86bc2b' });
      }
    });
  }
});
