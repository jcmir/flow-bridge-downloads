/**
 * Flow Bridge Chrome Extension — Background Service Worker & Control Sync (S1 Correction V3 / S2B Correction V2)
 * 
 * Periodically and on startup/install fetches signed control manifest from backend,
 * verifies Ed25519 signature against trusted public keyset, validates anti-rollback,
 * expiry, channel, and issued_at, and atomically updates verified control state in chrome.storage.local.
 * 
 * Integrates privacy-safe, isolated fleet telemetry client with persistent backoff,
 * alarm-driven retries, and advisory runtime reachability context.
 * 
 * Invariants:
 * - NO test backdoors in production service worker.
 * - NO unsigned long-lived bootstrap manifest.
 * - Fail-closed on missing verified control.
 * - Telemetry failure MUST NEVER break Flow Bridge or mutate S1 control gating.
 * - MAIN-world runtime signals are ADVISORY-only and cannot alter S1 control authority or patch gating.
 */

'use strict';

// Import verifier and telemetry client in service worker context
importScripts('crypto_verifier.js', 'telemetry_client.js');

const CONTROL_ENDPOINT = 'https://flow-bridge-release.jcmir.workers.dev/v1/extension/control';
const REFRESH_ALARM_NAME = 'fb_control_refresh_alarm';
const DEFAULT_REFRESH_MINUTES = 15;
const TELEMETRY_ALARM_NAME = 'fb_telemetry_alarm';
const TELEMETRY_RETRY_ALARM_NAME = 'fb_telemetry_retry_alarm';
const TELEMETRY_HEARTBEAT_MINUTES = 30;
const MAIN_SCRIPT_ID = 'flow_bridge_main_world';

// V5 EXPERIMENTAL PRIVILEGED ENFORCEMENT CONFIGURATION
// Experimental Mode: Privileged Chrome API unregistration with active tab reload tracking.
// Governance safety invariant: Auto-reload of open tabs requires explicit owner authorization.
const AUTO_RELOAD_ON_DISABLE_ENABLED = false;

// Instantiate isolated telemetry client in Extension context
const telemetryClient = (typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.TelemetryClient)
  ? new __FLOW_BRIDGE_TELEMETRY__.TelemetryClient()
  : null;

/**
 * Ensure required Chrome alarms exist across Service Worker sessions and restore pending retry alarms
 * Task 9 & 10: Runs on Service Worker initialization, onInstalled, and onStartup. All errors are non-fatal.
 */
async function ensureAlarms() {
  if (!chrome.alarms || typeof chrome.alarms.get !== 'function') return;
  try {
    const refreshAlarm = await chrome.alarms.get(REFRESH_ALARM_NAME).catch(() => null);
    if (!refreshAlarm) {
      chrome.alarms.create(REFRESH_ALARM_NAME, {
        periodInMinutes: DEFAULT_REFRESH_MINUTES
      });
    }

    const telemetryAlarm = await chrome.alarms.get(TELEMETRY_ALARM_NAME).catch(() => null);
    if (!telemetryAlarm) {
      chrome.alarms.create(TELEMETRY_ALARM_NAME, {
        periodInMinutes: TELEMETRY_HEARTBEAT_MINUTES
      });
    }

    // Inspect persisted retry state and restore retry alarm if a pending retry is active
    if (chrome.storage && chrome.storage.local && typeof chrome.storage.local.get === 'function') {
      const storage = await chrome.storage.local.get(['flow_bridge_telemetry_retry', 'flow_bridge_telemetry_queue', 'flow_bridge_telemetry_credential']).catch(() => ({}));
      const retryData = storage.flow_bridge_telemetry_retry;
      const queue = storage.flow_bridge_telemetry_queue;
      const hasPendingQueue = Array.isArray(queue) && queue.length > 0;
      const needsRegistrationRetry = !storage.flow_bridge_telemetry_credential;

      if (retryData && typeof retryData.next_retry_at === 'number' && retryData.next_retry_at > 0 && (hasPendingQueue || needsRegistrationRetry)) {
        const existingRetryAlarm = await chrome.alarms.get(TELEMETRY_RETRY_ALARM_NAME).catch(() => null);
        if (!existingRetryAlarm) {
          const nowMs = Date.now();
          const whenTime = retryData.next_retry_at > nowMs ? retryData.next_retry_at : (nowMs + 1000);
          chrome.alarms.create(TELEMETRY_RETRY_ALARM_NAME, { when: whenTime });
        }
      }
    }
  } catch (_) {
    // Alarm failures must never break execution
  }
}

/**
 * Synchronize dynamic registration of MAIN world content script via chrome.scripting
 * Invariants:
 * - Registered ONLY when verified control policy evaluates to allow_patch=true (ACTIVE).
 * - Unregistered whenever control is DISABLED, MAINTENANCE, UPDATE_REQUIRED, CONTROL_UNAVAILABLE, or expired.
 * - Script remains packaged inside extension (diagnostics.js + main_world.js).
 */
async function syncDynamicContentScriptRegistration(allowPatch) {
  if (!chrome.scripting || typeof chrome.scripting.registerContentScripts !== 'function') {
    return { ok: false, error: 'SCRIPTING_API_UNAVAILABLE' };
  }
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [MAIN_SCRIPT_ID] });
    const isRegistered = Array.isArray(existing) && existing.some(s => s.id === MAIN_SCRIPT_ID);

    if (allowPatch) {
      if (!isRegistered) {
        await chrome.scripting.registerContentScripts([{
          id: MAIN_SCRIPT_ID,
          js: ['diagnostics.js', 'main_world.js'],
          matches: ['https://flow.google.com/*'],
          world: 'MAIN',
          runAt: 'document_start',
          persistAcrossSessions: false
        }]);
        console.log('[Flow Bridge ServiceWorker] Registered dynamic MAIN patch script');
      }
    } else {
      if (isRegistered) {
        await chrome.scripting.unregisterContentScripts({ ids: [MAIN_SCRIPT_ID] });
        console.log('[Flow Bridge ServiceWorker] Unregistered dynamic MAIN patch script');
      }
    }

    // Post-enforcement verification of actual registered scripts
    const verifyScripts = await chrome.scripting.getRegisteredContentScripts({ ids: [MAIN_SCRIPT_ID] });
    const postRegistered = Array.isArray(verifyScripts) && verifyScripts.some(s => s.id === MAIN_SCRIPT_ID);
    if (allowPatch && !postRegistered) {
      throw new Error('POST_VERIFICATION_FAILED: Dynamic MAIN script not found after registration');
    }
    if (!allowPatch && postRegistered) {
      throw new Error('POST_VERIFICATION_FAILED: Dynamic MAIN script still present after unregistration');
    }

    return { ok: true };
  } catch (err) {
    console.warn('[Flow Bridge ServiceWorker] Error synchronizing dynamic content script registration:', err.message);
    if (telemetryClient && typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext) {
      chrome.storage.local.get(['flow_bridge_verified_control'], (st) => {
        const ctx = __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(st.flow_bridge_verified_control, st);
        telemetryClient.emitError('INJECTION_FAILED', ctx).catch(() => {});
      });
    }
    return { ok: false, error: err.message };
  }
}

/**
 * Update Chrome extension icon badge based on verified control state
 */
function updateActionBadge(effectiveState) {
  if (!chrome.action || typeof chrome.action.setBadgeText !== 'function') return;
  try {
    if (effectiveState === 'DISABLED') {
      chrome.action.setBadgeText({ text: 'OFF' });
      chrome.action.setBadgeBackgroundColor({ color: '#E53935' });
    } else if (effectiveState === 'MAINTENANCE') {
      chrome.action.setBadgeText({ text: 'PAUSE' });
      chrome.action.setBadgeBackgroundColor({ color: '#FB8C00' });
    } else if (effectiveState === 'UPDATE_REQUIRED') {
      chrome.action.setBadgeText({ text: 'UPD' });
      chrome.action.setBadgeBackgroundColor({ color: '#E65100' });
    } else if (effectiveState === 'ACTIVE') {
      chrome.action.setBadgeText({ text: '' });
    } else {
      // CONTROL_UNAVAILABLE or unknown
      chrome.action.setBadgeText({ text: '?' });
      chrome.action.setBadgeBackgroundColor({ color: '#757575' });
    }
  } catch (_) {}
}

/**
 * Broadcast one-way disable signal to any currently open Flow tabs
 * Out-of-band execution directly in MAIN world + isolated message delivery
 * Evaluates and categorizes each tab independently:
 * - MAIN_GATE_APPLIED
 * - MESSAGE_DELIVERED_ONLY
 * - ENFORCEMENT_UNCONFIRMED
 * - LOADING / DISCARDED
 */
async function notifyTabsOfDisable() {
  if (!chrome.tabs || !chrome.tabs.query) {
    return {
      totalTabs: 0,
      relevantActiveCount: 0,
      mainGateAppliedCount: 0,
      messageDeliveredOnlyCount: 0,
      unconfirmedCount: 0,
      loadingCount: 0,
      discardedCount: 0,
      deliveredCount: 0,
      tabEvaluations: [],
      errors: []
    };
  }
  let totalTabs = 0;
  let relevantActiveCount = 0;
  let mainGateAppliedCount = 0;
  let messageDeliveredOnlyCount = 0;
  let unconfirmedCount = 0;
  let loadingCount = 0;
  let discardedCount = 0;
  let deliveredCount = 0;
  const tabEvaluations = [];
  const errors = [];
  try {
    const tabs = await chrome.tabs.query({ url: 'https://flow.google.com/*' });
    totalTabs = tabs.length;
    for (const tab of tabs) {
      if (!tab.id) continue;
      // Discarded tabs have no active execution context; they reload fresh on selection
      if (tab.discarded) {
        discardedCount++;
        tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'DISCARDED' });
        continue;
      }
      // Tabs currently navigating/loading: active execution context is not established/confirmed
      if (tab.status === 'loading') {
        loadingCount++;
        tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'LOADING' });
        continue;
      }

      relevantActiveCount++;
      let tabGateApplied = false;
      let tabDelivered = false;

      // 1. Direct out-of-band executeScript in MAIN world with strict descriptor & latch verification
      if (chrome.scripting && chrome.scripting.executeScript) {
        try {
          const injectionResults = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: () => {
              try {
                const desc = Object.getOwnPropertyDescriptor(window, '__FLOW_BRIDGE_FORCE_DISABLE__');
                const isAuthenticDesc = Boolean(desc && desc.configurable === false && desc.writable === false && typeof desc.value === 'function');
                let hookResult = null;
                let latchApplied = false;

                if (isAuthenticDesc) {
                  try {
                    hookResult = desc.value();
                    const latchDesc = Object.getOwnPropertyDescriptor(window, '__FLOW_BRIDGE_FORCE_DISABLE_LATCH__');
                    const isLatchConfirmed = Boolean(latchDesc && latchDesc.configurable === false && latchDesc.writable === false && latchDesc.value === true);
                    if (isLatchConfirmed && hookResult && (hookResult.applied === true || hookResult.permanentlyDisabled === true)) {
                      latchApplied = true;
                    }
                  } catch (hookErr) {
                    hookResult = { error: hookErr.message };
                  }
                }

                if (document.documentElement) {
                  document.documentElement.dataset.flowBridgeDisabled = 'true';
                  document.documentElement.dataset.flowBridgeState = 'DISABLED';
                }

                return {
                  hookPresent: isAuthenticDesc,
                  latchApplied,
                  hookResult,
                  domDatasetSet: Boolean(document.documentElement && document.documentElement.dataset.flowBridgeDisabled === 'true')
                };
              } catch (evalErr) {
                return {
                  hookPresent: false,
                  latchApplied: false,
                  error: evalErr.message
                };
              }
            }
          });

          // Verify that execution succeeded AND actually applied authentic hook latch
          if (Array.isArray(injectionResults) && injectionResults.length > 0) {
            const mainResult = injectionResults[0].result;
            if (mainResult && mainResult.hookPresent === true && mainResult.latchApplied === true) {
              tabGateApplied = true;
            }
          }

          if (!tabGateApplied) {
            errors.push({
              tabId: tab.id,
              error: 'MAIN_HOOK_UNAUTHENTIC_OR_NOT_CONFIRMED',
              details: (Array.isArray(injectionResults) && injectionResults[0]) ? injectionResults[0].result : null
            });
          }
        } catch (execErr) {
          errors.push({ tabId: tab.id, error: execErr.message });
        }
      }

      // 2. Deliver runtime message to isolated bootstrap
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'FLOW_BRIDGE_DISABLE' });
        deliveredCount++;
        tabDelivered = true;
      } catch (tabErr) {
        // Message could not be delivered to isolated context
      }

      // 3. Mutually exclusive per-tab categorization
      if (tabGateApplied) {
        mainGateAppliedCount++;
        tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'MAIN_GATE_APPLIED' });
      } else if (tabDelivered) {
        messageDeliveredOnlyCount++;
        tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'MESSAGE_DELIVERED_ONLY' });
      } else {
        unconfirmedCount++;
        tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'ENFORCEMENT_UNCONFIRMED' });
      }
    }
  } catch (err) {
    console.warn('[Flow Bridge ServiceWorker] Failed to query tabs for disable notification:', err.message);
    return {
      totalTabs,
      relevantActiveCount,
      mainGateAppliedCount,
      messageDeliveredOnlyCount,
      unconfirmedCount,
      loadingCount,
      discardedCount,
      deliveredCount,
      tabEvaluations,
      queryError: err.message,
      errors
    };
  }
  return {
    totalTabs,
    relevantActiveCount,
    mainGateAppliedCount,
    messageDeliveredOnlyCount,
    unconfirmedCount,
    loadingCount,
    discardedCount,
    deliveredCount,
    tabEvaluations,
    errors
  };
}

/**
 * Fetch signed control envelope from backend with no-cache.
 * VULN-001 Hardening: Strictly locks down customUrl to match authorized CONTROL_ENDPOINT.
 */
async function fetchSignedControl(customUrl) {
  let targetUrl = CONTROL_ENDPOINT + '?channel=' + __FLOW_BRIDGE_CRYPTO__.DEFAULT_CHANNEL + '&version=' + chrome.runtime.getManifest().version;

  if (customUrl && typeof customUrl === 'string') {
    try {
      const candidateUrl = new URL(customUrl);
      const authorizedUrl = new URL(CONTROL_ENDPOINT);
      if (candidateUrl.origin === authorizedUrl.origin && candidateUrl.pathname === authorizedUrl.pathname) {
        targetUrl = customUrl;
      } else {
        console.warn('[Flow Bridge ServiceWorker] Unauthorized customUrl rejected by security gate:', customUrl);
      }
    } catch (_) {
      console.warn('[Flow Bridge ServiceWorker] Malformed customUrl rejected');
    }
  }

  const response = await fetch(targetUrl, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Cache-Control': 'no-cache'
    }
  });

  if (!response.ok) {
    throw new Error('HTTP ' + response.status + ' fetching remote control');
  }

  return await response.json();
}

/**
 * Determine accurate patch gate enforcement outcome based on scripting and tab delivery results
 * States: PATCH_GATE_CONFIRMED, SCRIPT_REGISTRATION_FAILED, SCRIPT_UNREGISTRATION_FAILED,
 *         ENFORCEMENT_UNCONFIRMED, MAIN_GATE_APPLIED, MESSAGE_DELIVERED, SCRIPT_UNREGISTERED
 */
function determineEnforcementOutcome(allowPatch, syncResult, tabNotifyResult, previousEnforcedRev, targetRevision) {
  if (allowPatch) {
    if (syncResult && syncResult.ok) {
      return {
        enforcement_result: 'PATCH_GATE_CONFIRMED',
        enforced_revision: targetRevision,
        error_code: null
      };
    } else {
      return {
        enforcement_result: 'SCRIPT_REGISTRATION_FAILED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'SCRIPT_ENFORCEMENT_FAILED'
      };
    }
  } else {
    // allowPatch === false (DISABLE / BLOCK)
    if (!syncResult || !syncResult.ok) {
      return {
        enforcement_result: 'SCRIPT_UNREGISTRATION_FAILED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'SCRIPT_ENFORCEMENT_FAILED'
      };
    }

    if (!tabNotifyResult || tabNotifyResult.queryError) {
      return {
        enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'TAB_QUERY_ERROR'
      };
    }

    // No open Flow tabs: content scripts unregistered, future loads blocked
    if (tabNotifyResult.totalTabs === 0) {
      return {
        enforcement_result: 'SCRIPT_UNREGISTERED',
        enforced_revision: targetRevision,
        error_code: null
      };
    }

    // Any tab failed both MAIN gate and message delivery
    if (tabNotifyResult.unconfirmedCount > 0) {
      return {
        enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'TAB_ENFORCEMENT_UNCONFIRMED'
      };
    }

    // Any tab currently loading (navigation race in progress)
    if (tabNotifyResult.loadingCount > 0) {
      return {
        enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'TAB_NAVIGATION_RACE'
      };
    }

    const relevantCount = tabNotifyResult.relevantActiveCount || 0;

    // Discarded-only tabs (no active execution contexts)
    if (relevantCount === 0 && (tabNotifyResult.discardedCount > 0)) {
      return {
        enforcement_result: 'SCRIPT_UNREGISTERED',
        enforced_revision: targetRevision,
        error_code: null
      };
    }

    // Strict Rule: MAIN_GATE_APPLIED ONLY IF 100% OF RELEVANT ACTIVE TABS HAVE AUTHENTIC MAIN GATE CONFIRMED
    if (relevantCount > 0 && tabNotifyResult.mainGateAppliedCount === relevantCount) {
      return {
        enforcement_result: 'MAIN_GATE_APPLIED',
        enforced_revision: targetRevision,
        error_code: null
      };
    }

    // Partial enforcement: some tabs applied MAIN gate, but others only got message or unconfirmed
    if (tabNotifyResult.mainGateAppliedCount > 0 && tabNotifyResult.mainGateAppliedCount < relevantCount) {
      return {
        enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'TAB_MAIN_GATE_INCOMPLETE'
      };
    }

    // All active tabs received runtime message, but zero tabs confirmed authentic MAIN gate
    if (tabNotifyResult.messageDeliveredOnlyCount === relevantCount && relevantCount > 0) {
      return {
        enforcement_result: 'MESSAGE_DELIVERED_ONLY',
        enforced_revision: previousEnforcedRev || null,
        error_code: 'MAIN_LATCH_UNCONFIRMED'
      };
    }

    return {
      enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
      enforced_revision: previousEnforcedRev || null,
      error_code: 'TAB_ENFORCEMENT_UNCONFIRMED'
    };
  }
}

/**
 * V5 Privileged Chrome API Enforcement Engine for DISABLED state.
 * Implements alternative enforcement via Chrome privileged APIs:
 * - Unregisters dynamic MAIN content script from Chrome internal registry.
 * - Confirms Chrome registration state (must report 0 registered scripts).
 * - Queries existing Flow tabs.
 * - Initiates chrome.tabs.reload(tab.id) for all relevant active tabs.
 * - Tracks navigation completion (polls until status === 'complete' or timeout).
 * - Never declares full execution if reload fails, hangs, or state is unconfirmed.
 * - Discarded tabs reload fresh upon user activation; confirmed without race.
 */
async function enforcePrivilegedDisabled(targetRevision, previousEnforcedRev, options = {}) {
  const timeoutMs = options.timeoutMs || 2000;
  const pollIntervalMs = options.pollIntervalMs || 50;
  const autoReload = (typeof options.autoReload === 'boolean') ? options.autoReload : AUTO_RELOAD_ON_DISABLE_ENABLED;

  // 1. Unregister script via chrome.scripting
  let unregisterError = null;
  if (chrome.scripting && chrome.scripting.unregisterContentScripts) {
    try {
      await chrome.scripting.unregisterContentScripts({ ids: [MAIN_SCRIPT_ID] });
    } catch (err) {
      unregisterError = err.message;
    }
  }

  // 2. Machine verify Chrome internal registry
  if (!chrome.scripting || !chrome.scripting.getRegisteredContentScripts) {
    return {
      enforcement_result: 'SCRIPT_UNREGISTRATION_FAILED',
      enforced_revision: previousEnforcedRev || null,
      error_code: 'CHROME_SCRIPTING_UNAVAILABLE',
      details: { unregisterError }
    };
  }

  const registeredScripts = await chrome.scripting.getRegisteredContentScripts();
  const isStillRegistered = Array.isArray(registeredScripts) && registeredScripts.some(s => s.id === MAIN_SCRIPT_ID);
  if (isStillRegistered) {
    return {
      enforcement_result: 'SCRIPT_UNREGISTRATION_FAILED',
      enforced_revision: previousEnforcedRev || null,
      error_code: 'CHROME_REGISTRATION_STILL_ACTIVE',
      details: { remainingCount: registeredScripts.length }
    };
  }

  // 3. Query existing Flow tabs
  if (!chrome.tabs || !chrome.tabs.query) {
    return {
      enforcement_result: 'SCRIPT_UNREGISTERED',
      enforced_revision: targetRevision,
      error_code: null,
      details: { totalTabs: 0, reason: 'TABS_API_UNAVAILABLE' }
    };
  }

  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: 'https://flow.google.com/*' });
  } catch (err) {
    return {
      enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
      enforced_revision: previousEnforcedRev || null,
      error_code: 'TAB_QUERY_ERROR',
      details: { error: err.message }
    };
  }

  if (tabs.length === 0) {
    return {
      enforcement_result: 'SCRIPT_UNREGISTERED',
      enforced_revision: targetRevision,
      error_code: null,
      details: { totalTabs: 0 }
    };
  }

  // 4. Evaluate tabs
  const tabEvaluations = [];
  let relevantActiveCount = 0;
  let discardedCount = 0;
  const activeTabs = [];

  for (const tab of tabs) {
    if (!tab.id) continue;

    if (tab.discarded) {
      discardedCount++;
      tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'DISCARDED' });
      continue;
    }

    relevantActiveCount++;
    activeTabs.push(tab);
  }

  // If no active tabs running, unregistration guarantees future loads are blocked
  if (relevantActiveCount === 0) {
    return {
      enforcement_result: 'SCRIPT_UNREGISTERED',
      enforced_revision: targetRevision,
      error_code: null,
      details: { totalTabs: tabs.length, discardedCount, tabEvaluations }
    };
  }

  // Best-effort in-tab notification without treating page reflection as proof
  for (const tab of activeTabs) {
    if (chrome.tabs && chrome.tabs.sendMessage) {
      chrome.tabs.sendMessage(tab.id, { type: 'FLOW_BRIDGE_DISABLE' }).catch(() => {});
    }
  }

  // Safety Gate: Auto-reload disabled by default until explicit owner authorization
  if (!autoReload) {
    for (const tab of activeTabs) {
      tabEvaluations.push({ tabId: tab.id, status: tab.status, category: 'AWAITING_RELOAD_PERMIT' });
    }
    return {
      enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
      enforced_revision: previousEnforcedRev || null,
      error_code: 'AWAITING_OWNER_RELOAD_AUTHORIZATION',
      details: { totalTabs: tabs.length, relevantActiveCount, tabEvaluations }
    };
  }

  // 5. Track reload and verify fresh navigation for each active tab independently
  const trackers = new Map();
  for (const tab of activeTabs) {
    trackers.set(tab.id, {
      tabId: tab.id,
      initialStatus: tab.status,
      reloadRequested: false,
      reloadRequestTime: 0,
      reloadError: null,
      navigationStarted: false,
      navigationCompleted: false,
      closed: false,
      lastObservedStatus: tab.status || 'unknown'
    });
  }

  // Subscribe to navigation events BEFORE requesting reloads
  let onUpdatedListener = null;
  let onRemovedListener = null;

  if (chrome.tabs && chrome.tabs.onUpdated && chrome.tabs.onUpdated.addListener) {
    onUpdatedListener = (updatedTabId, changeInfo, updatedTab) => {
      const tr = trackers.get(updatedTabId);
      if (!tr || !tr.reloadRequested) return;

      if (changeInfo.status) {
        tr.lastObservedStatus = changeInfo.status;
      }

      if (changeInfo.status === 'loading') {
        tr.navigationStarted = true;
      } else if (changeInfo.status === 'complete') {
        // STRICT REQUIREMENT: Only accept complete if new navigation started after reload!
        if (tr.navigationStarted) {
          tr.navigationCompleted = true;
        }
      }
    };
    chrome.tabs.onUpdated.addListener(onUpdatedListener);
  }

  if (chrome.tabs && chrome.tabs.onRemoved && chrome.tabs.onRemoved.addListener) {
    onRemovedListener = (removedTabId) => {
      const tr = trackers.get(removedTabId);
      if (tr) {
        tr.closed = true;
        tr.lastObservedStatus = 'CLOSED';
      }
    };
    chrome.tabs.onRemoved.addListener(onRemovedListener);
  }

  try {
    // Request reloads for all active tabs
    for (const tab of activeTabs) {
      const tr = trackers.get(tab.id);
      tr.reloadRequested = true;
      tr.reloadRequestTime = Date.now();
      try {
        if (chrome.tabs && chrome.tabs.reload) {
          await chrome.tabs.reload(tab.id);
        } else {
          tr.reloadError = 'TABS_RELOAD_UNAVAILABLE';
        }
      } catch (err) {
        tr.reloadError = err.message;
      }
    }

    const startTime = Date.now();
    while (Date.now() - startTime < timeoutMs) {
      let allResolved = true;

      for (const [tabId, tr] of trackers.entries()) {
        if (tr.reloadError || tr.closed || tr.navigationCompleted) {
          continue;
        }

        allResolved = false;

        if (chrome.tabs && chrome.tabs.get) {
          try {
            const currentTab = await chrome.tabs.get(tabId);
            if (!currentTab) {
              tr.closed = true;
              tr.lastObservedStatus = 'CLOSED';
              continue;
            }

            tr.lastObservedStatus = currentTab.status;

            if (currentTab.status === 'loading') {
              tr.navigationStarted = true;
            } else if (currentTab.status === 'complete') {
              // STRICT: Only complete if navigation was confirmed to have started!
              if (tr.navigationStarted) {
                tr.navigationCompleted = true;
              }
              // If navigationStarted is false, do NOT set navigationCompleted! This is the old complete!
            }
          } catch (getErr) {
            tr.closed = true;
            tr.lastObservedStatus = 'ERROR_' + getErr.message;
          }
        }
      }

      if (allResolved) {
        break;
      }

      await new Promise(r => setTimeout(r, pollIntervalMs));
    }
  } finally {
    if (onUpdatedListener && chrome.tabs && chrome.tabs.onUpdated && chrome.tabs.onUpdated.removeListener) {
      try { chrome.tabs.onUpdated.removeListener(onUpdatedListener); } catch (_) {}
    }
    if (onRemovedListener && chrome.tabs && chrome.tabs.onRemoved && chrome.tabs.onRemoved.removeListener) {
      try { chrome.tabs.onRemoved.removeListener(onRemovedListener); } catch (_) {}
    }
  }

  let reloadedAndCompletedCount = 0;
  let reloadFailedCount = 0;
  let navigationPendingCount = 0;

  for (const [tabId, tr] of trackers.entries()) {
    if (tr.reloadError) {
      reloadFailedCount++;
      tabEvaluations.push({ tabId, status: tr.lastObservedStatus, category: 'RELOAD_FAILED', error: tr.reloadError });
    } else if (tr.closed) {
      navigationPendingCount++;
      tabEvaluations.push({ tabId, status: 'CLOSED', category: 'TAB_CLOSED_ABORTED' });
    } else if (tr.navigationCompleted) {
      reloadedAndCompletedCount++;
      tabEvaluations.push({ tabId, status: 'complete', category: 'RELOAD_COMPLETED' });
    } else if (!tr.navigationStarted) {
      navigationPendingCount++;
      tabEvaluations.push({ tabId, status: tr.lastObservedStatus, category: 'NAVIGATION_UNCONFIRMED', error: 'NO_NEW_NAVIGATION_OBSERVED' });
    } else {
      navigationPendingCount++;
      tabEvaluations.push({ tabId, status: tr.lastObservedStatus, category: 'NAVIGATION_INCOMPLETE', error: 'NAVIGATION_TIMEOUT' });
    }
  }

  // Step 6: Formulate outcome
  const allActiveCompleted = (
    relevantActiveCount > 0 &&
    reloadedAndCompletedCount === relevantActiveCount &&
    reloadFailedCount === 0 &&
    navigationPendingCount === 0
  );

  if (allActiveCompleted) {
    return {
      enforcement_result: 'PRIVILEGED_RELOAD_CONFIRMED',
      enforced_revision: targetRevision,
      error_code: null,
      details: {
        totalTabs: tabs.length,
        relevantActiveCount,
        reloadedAndCompletedCount,
        tabEvaluations
      }
    };
  }

  let errorCode = 'TAB_RELOAD_INCOMPLETE';
  if (reloadFailedCount > 0) {
    errorCode = 'TAB_RELOAD_FAILED';
  } else if (navigationPendingCount > 0) {
    const hasUnconfirmed = tabEvaluations.some(e => e.category === 'NAVIGATION_UNCONFIRMED');
    errorCode = hasUnconfirmed ? 'TAB_NAVIGATION_UNCONFIRMED' : 'TAB_NAVIGATION_RACE';
  }

  return {
    enforcement_result: 'ENFORCEMENT_UNCONFIRMED',
    enforced_revision: previousEnforcedRev || null,
    error_code: errorCode,
    details: {
      totalTabs: tabs.length,
      relevantActiveCount,
      reloadedAndCompletedCount,
      reloadFailedCount,
      navigationPendingCount,
      discardedCount,
      tabEvaluations
    }
  };
}

/**
 * Process, cryptographically verify, and adopt a control envelope
 * Executes full production verification pipeline:
 * 1. Cryptographic Ed25519 signature verification
 * 2. Trusted key lookup & status verification
 * 3. Issued-at / Expiry validation with bounded clock skew
 * 4. Channel validation
 * 5. Monotonic anti-rollback enforcement & Same-revision consistency check
 * 6. Minimum & latest version compatibility policy
 * 7. Atomic storage update
 * 8. Dynamic content script registration / unregistration with post-verification and tab confirmation
 */
async function processAndAdoptControlEnvelope(envelope, customTrustedKeys, sourceLabel, options = {}) {
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const installedVersion = chrome.runtime.getManifest().version;
  const storage = await chrome.storage.local.get(['flow_bridge_verified_control', 'highest_revision', 'flow_bridge_latest_diag', 'last_enforced_revision']);
  const currentHighestRevision = storage.highest_revision || 0;
  const previousEnforcedRev = storage.last_enforced_revision || null;
  const trustedKeys = customTrustedKeys || __FLOW_BRIDGE_CRYPTO__.TRUSTED_PUBLIC_KEYS;

  const adoptResult = await __FLOW_BRIDGE_CRYPTO__.validateAndAdoptManifest(
    envelope,
    currentHighestRevision,
    installedVersion,
    nowMs,
    trustedKeys,
    __FLOW_BRIDGE_CRYPTO__.DEFAULT_CHANNEL,
    storage.flow_bridge_verified_control
  );

  if (!adoptResult.adopted) {
    const isSameRev = (adoptResult.rejection_reason === 'SAME_REVISION_NO_CHANGE');
    if (!isSameRev) {
      console.warn('[Flow Bridge ServiceWorker] Control envelope rejected:', adoptResult.rejection_reason);
    }
    const cached = storage.flow_bridge_verified_control;
    const currentPolicy = cached && cached.verified_manifest
      ? __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(cached.verified_manifest, installedVersion, nowMs)
      : { state: 'CONTROL_UNAVAILABLE', allow_patch: false };

    updateActionBadge(currentPolicy.state);
    let outcome = null;
    if (currentPolicy.allow_patch === true) {
      const syncResult = await syncDynamicContentScriptRegistration(true);
      outcome = determineEnforcementOutcome(
        true,
        syncResult,
        null,
        previousEnforcedRev,
        currentHighestRevision
      );
    } else {
      outcome = await enforcePrivilegedDisabled(
        currentHighestRevision,
        previousEnforcedRev,
        options
      );
    }

    const errorCode = isSameRev ? outcome.error_code : (outcome.error_code || adoptResult.rejection_reason);

    await chrome.storage.local.set({
      last_fetch_success: nowIso,
      last_enforced_revision: outcome.enforced_revision,
      last_enforcement_result: isSameRev ? outcome.enforcement_result : adoptResult.rejection_reason,
      last_error_code: errorCode
    });

    // Exact S1 rejection mapping
    if (!isSameRev && telemetryClient && typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext) {
      let errCat = null;
      const reason = adoptResult.rejection_reason;

      if (reason === 'CONTROL_EXPIRED') {
        errCat = 'CONTROL_EXPIRED';
      } else if (reason === 'CONTROL_ROLLBACK_REJECTED') {
        const candidateRev = (envelope && envelope.payload && typeof envelope.payload.revision === 'number')
          ? envelope.payload.revision
          : ((envelope && typeof envelope.revision === 'number') ? envelope.revision : null);

        if (candidateRev !== null && candidateRev < currentHighestRevision) {
          errCat = 'ROLLBACK_REJECTED';
        }
      } else if (reason === 'SAME_REVISION_PAYLOAD_CONFLICT' || reason === 'SAME_REVISION_UNTRUSTED_CACHE') {
        errCat = 'AUTHORITY_CONFLICT';
      } else if (reason) {
        errCat = 'CONTROL_VERIFICATION_FAILED';
      }

      if (errCat) {
        const ctx = __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(storage.flow_bridge_verified_control, storage);
        telemetryClient.emitError(errCat, ctx).catch(() => {});
      }
    }

    return {
      status: isSameRev ? 'NO_CHANGE' : 'REJECTED',
      rejection_reason: adoptResult.rejection_reason,
      state: currentPolicy.state,
      allow_patch: currentPolicy.allow_patch,
      highest_revision: currentHighestRevision,
      last_enforcement_result: isSameRev ? outcome.enforcement_result : adoptResult.rejection_reason
    };
  }

  // Atomically update storage with verified control record and diagnostic fields
  adoptResult.source = sourceLabel || 'LIVE_SIGNED';
  let outcome = null;
  if (adoptResult.allow_patch === true) {
    const syncResult = await syncDynamicContentScriptRegistration(true);
    outcome = determineEnforcementOutcome(
      true,
      syncResult,
      null,
      previousEnforcedRev,
      adoptResult.new_highest_revision
    );
  } else {
    outcome = await enforcePrivilegedDisabled(
      adoptResult.new_highest_revision,
      previousEnforcedRev,
      options
    );
  }

  await chrome.storage.local.set({
    flow_bridge_verified_control: adoptResult,
    highest_revision: adoptResult.new_highest_revision,
    last_fetch_timestamp: nowIso,
    last_fetch_success: nowIso,
    last_adopted_revision: adoptResult.new_highest_revision,
    last_enforced_revision: outcome.enforced_revision,
    last_enforcement_result: outcome.enforcement_result,
    last_error_code: outcome.error_code
  });

  updateActionBadge(adoptResult.effective_state);

  // Telemetry Observation: Emit CONTROL_ADOPTED event without affecting S1 authority
  if (telemetryClient && typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext) {
    const updatedStorage = {
      flow_bridge_verified_control: adoptResult,
      flow_bridge_latest_diag: storage.flow_bridge_latest_diag
    };
    const runtimeCtx = __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(adoptResult, updatedStorage);
    telemetryClient.emitControlAdopted(adoptResult, runtimeCtx).catch(() => {});
  }

  console.log('[Flow Bridge ServiceWorker] Verified control updated successfully. State:', adoptResult.effective_state, 'Revision:', adoptResult.new_highest_revision, 'Outcome:', outcome.enforcement_result);
  return {
    status: 'UPDATED',
    ok: true,
    state: adoptResult.effective_state,
    revision: adoptResult.new_highest_revision,
    allow_patch: adoptResult.allow_patch,
    lkg_status: adoptResult.lkg_status,
    source: adoptResult.source,
    last_enforcement_result: outcome.enforcement_result
  };
}

/**
 * Perform remote control sync, verification, and atomic storage update
 */
async function syncRemoteControl(customUrlOrOptions, options = {}) {
  let customUrl = undefined;
  let opts = {};

  if (typeof customUrlOrOptions === 'string') {
    customUrl = customUrlOrOptions;
    opts = options || {};
  } else if (typeof customUrlOrOptions === 'boolean') {
    opts = { autoReload: customUrlOrOptions, ...(options || {}) };
  } else if (typeof customUrlOrOptions === 'object' && customUrlOrOptions !== null) {
    opts = { ...customUrlOrOptions, ...(options || {}) };
    if (opts.customUrl) customUrl = opts.customUrl;
  } else {
    opts = options || {};
  }

  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const installedVersion = chrome.runtime.getManifest().version;
  const storage = await chrome.storage.local.get(['flow_bridge_verified_control', 'highest_revision', 'flow_bridge_latest_diag', 'last_enforced_revision']);
  const previousEnforcedRev = storage.last_enforced_revision || null;

  // Record fetch attempt timestamp
  await chrome.storage.local.set({ last_fetch_attempt: nowIso });

  let envelope;
  try {
    envelope = await fetchSignedControl(customUrl);
  } catch (err) {
    console.warn('[Flow Bridge ServiceWorker] Remote control fetch failed, evaluating offline policy:', err.message);
    
    // Telemetry observation: remote control fetch failure
    if (telemetryClient && typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext) {
      const ctx = __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(storage.flow_bridge_verified_control, storage);
      telemetryClient.emitError('CONTROL_FETCH_FAILED', ctx).catch(() => {});
    }

    // Evaluate cached verified state under bounded LKG policy
    const cached = storage.flow_bridge_verified_control;
    if (cached && cached.verified_manifest) {
      const offlinePolicy = __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(
        cached.verified_manifest,
        installedVersion,
        nowMs
      );
      console.log('[Flow Bridge ServiceWorker] Evaluated cached control policy:', offlinePolicy.state, offlinePolicy.lkg_status);
      const targetRev = (cached.verified_manifest && cached.verified_manifest.revision) || null;
      let outcome;
      if (offlinePolicy.allow_patch === true) {
        const syncResult = await syncDynamicContentScriptRegistration(true);
        outcome = determineEnforcementOutcome(
          true,
          syncResult,
          null,
          previousEnforcedRev,
          targetRev
        );
      } else {
        outcome = await enforcePrivilegedDisabled(
          targetRev,
          previousEnforcedRev,
          opts
        );
      }

      await chrome.storage.local.set({
        last_enforced_revision: outcome.enforced_revision,
        last_enforcement_result: outcome.enforcement_result,
        last_error_code: outcome.error_code || 'CONTROL_FETCH_FAILED'
      });

      return {
        status: 'OFFLINE_CACHE_EVALUATED',
        ok: true,
        state: offlinePolicy.state,
        allow_patch: offlinePolicy.allow_patch,
        lkg_status: offlinePolicy.lkg_status,
        source: 'CACHE',
        last_enforcement_result: outcome.enforcement_result
      };
    }

    // First install offline with no verified control: Fail closed!
    console.warn('[Flow Bridge ServiceWorker] No verified control cached and backend unreachable. Gating FAIL_CLOSED.');
    const outcome = await enforcePrivilegedDisabled(null, previousEnforcedRev, opts);

    await chrome.storage.local.set({
      last_enforced_revision: null,
      last_enforcement_result: 'CONTROL_UNAVAILABLE_FAIL_CLOSED',
      last_error_code: 'CONTROL_FETCH_FAILED'
    });

    return {
      status: 'CONTROL_UNAVAILABLE',
      ok: false,
      state: 'CONTROL_UNAVAILABLE',
      allow_patch: false,
      lkg_status: 'NONE',
      source: 'NONE',
      last_enforcement_result: 'CONTROL_UNAVAILABLE_FAIL_CLOSED'
    };
  }

  return await processAndAdoptControlEnvelope(envelope, null, 'LIVE_SIGNED', opts);
}
if (typeof self !== 'undefined') self.syncRemoteControl = syncRemoteControl;
if (typeof self !== 'undefined') self.processAndAdoptControlEnvelope = processAndAdoptControlEnvelope;
if (typeof self !== 'undefined') self.syncDynamicContentScriptRegistration = syncDynamicContentScriptRegistration;
if (typeof self !== 'undefined') self.notifyTabsOfDisable = notifyTabsOfDisable;
if (typeof self !== 'undefined') self.determineEnforcementOutcome = determineEnforcementOutcome;

// Evaluate cached policy and sync dynamic registration on startup / install
async function initStartupGate() {
  try {
    const storage = await chrome.storage.local.get(['flow_bridge_verified_control']);
    const cached = storage.flow_bridge_verified_control;
    const installedVersion = chrome.runtime.getManifest().version;
    const nowMs = Date.now();
    if (cached && cached.verified_manifest) {
      const policy = __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(cached.verified_manifest, installedVersion, nowMs);
      updateActionBadge(policy.state);
      await syncDynamicContentScriptRegistration(policy.allow_patch === true);
    } else {
      updateActionBadge('CONTROL_UNAVAILABLE');
      await syncDynamicContentScriptRegistration(false);
    }
  } catch (_) {
    updateActionBadge('CONTROL_UNAVAILABLE');
    await syncDynamicContentScriptRegistration(false);
  }
}

/**
 * Trigger background startup telemetry without blocking worker startup or S1 gating
 */
function triggerStartupTelemetry() {
  if (!telemetryClient) return;
  chrome.storage.local.get(['flow_bridge_verified_control', 'flow_bridge_latest_diag'], (st) => {
    const ctx = (typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined' && __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext)
      ? __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(st.flow_bridge_verified_control, st)
      : {};
    telemetryClient.register().catch(() => {});
    telemetryClient.emitStartup(ctx).catch(() => {});
  });
}

// Service Worker Top-Level Script Initialization: Ensure alarms exist (Task 9)
ensureAlarms().catch(() => {});

if (chrome.tabs && chrome.tabs.onActivated) {
  chrome.tabs.onActivated.addListener(() => {
    syncRemoteControl().catch(() => {});
  });
}

// Service Worker Lifecycle Listeners
chrome.runtime.onInstalled.addListener(async (details) => {
  await initStartupGate();
  await ensureAlarms();
  syncRemoteControl().catch(() => {});
  triggerStartupTelemetry();
});

chrome.runtime.onStartup.addListener(async () => {
  await initStartupGate();
  await ensureAlarms();
  syncRemoteControl().catch(() => {});
  triggerStartupTelemetry();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === REFRESH_ALARM_NAME) {
    syncRemoteControl().catch(() => {});
  }

  if (alarm && alarm.name === TELEMETRY_RETRY_ALARM_NAME) {
    if (telemetryClient) {
      telemetryClient.flushQueue().catch(() => {});
    }
  }

  if (alarm && alarm.name === TELEMETRY_ALARM_NAME) {
    if (telemetryClient && typeof __FLOW_BRIDGE_TELEMETRY__ !== 'undefined') {
      chrome.storage.local.get([
        'flow_bridge_verified_control',
        'flow_bridge_last_update',
        'flow_bridge_latest_diag'
      ], (storage) => {
        // Enforce recent Flow activity requirement for routine heartbeats (Task 7)
        if (__FLOW_BRIDGE_TELEMETRY__.hasRecentFlowActivity && !__FLOW_BRIDGE_TELEMETRY__.hasRecentFlowActivity(storage)) {
          return;
        }
        const context = __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext
          ? __FLOW_BRIDGE_TELEMETRY__.buildSanitizedRuntimeContext(storage.flow_bridge_verified_control, storage)
          : {};
        telemetryClient.emitHeartbeat(context).catch(() => {});
      });
    }
  }
});

// React to storage updates and synchronize dynamic registration
chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName === 'local' && changes.flow_bridge_verified_control) {
    const record = changes.flow_bridge_verified_control.newValue;
    const installedVersion = chrome.runtime.getManifest().version;
    const nowMs = Date.now();
    if (record && record.verified_manifest) {
      const policy = __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(record.verified_manifest, installedVersion, nowMs);
      await syncDynamicContentScriptRegistration(policy.allow_patch === true);
    } else {
      await syncDynamicContentScriptRegistration(false);
    }
  }
});

// Handle popup / diagnostics messages (read-only and refresh triggers)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request && request.type === 'REFRESH_REMOTE_CONTROL') {
    const opts = request.options || (typeof request.autoReload === 'boolean' ? { autoReload: request.autoReload } : {});
    syncRemoteControl(request.customUrl, opts)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ status: 'ERROR', error: err.message }));
    return true;
  }

  if (request && request.type === 'GET_DYNAMIC_REGISTRATION_STATUS') {
    if (!chrome.scripting || !chrome.scripting.getRegisteredContentScripts) {
      sendResponse({ status: 'OK', registered: [] });
      return false;
    }
    chrome.scripting.getRegisteredContentScripts({ ids: [MAIN_SCRIPT_ID] })
      .then(scripts => sendResponse({ status: 'OK', registered: scripts }))
      .catch(err => sendResponse({ status: 'ERROR', error: err.message }));
    return true;
  }

  if (request && request.type === 'GET_CONTROL_STATUS') {
    chrome.storage.local.get(['flow_bridge_verified_control', 'last_fetch_timestamp'], (storage) => {
      const cached = storage.flow_bridge_verified_control;
      const installedVersion = chrome.runtime.getManifest().version;
      const nowMs = Date.now();
      let policy;
      if (cached && cached.verified_manifest) {
        policy = __FLOW_BRIDGE_CRYPTO__.evaluateControlPolicy(cached.verified_manifest, installedVersion, nowMs);
      } else {
        policy = {
          allow_patch: false,
          state: 'CONTROL_UNAVAILABLE',
          reason: 'NO_VERIFIED_CONTROL',
          lkg_status: 'NONE'
        };
      }
      sendResponse({
        status: 'OK',
        policy: policy,
        cached_record: cached || null,
        last_fetch: storage.last_fetch_timestamp || null
      });
    });
    return true;
  }

  if (request && request.type === 'GET_TELEMETRY_STATUS') {
    if (telemetryClient) {
      telemetryClient.getDiagnostics(Boolean(request.isOperator))
        .then(diag => sendResponse({ status: 'OK', diagnostics: diag }))
        .catch(err => sendResponse({ status: 'ERROR', error: err.message }));
      return true;
    } else {
      sendResponse({ status: 'UNAVAILABLE' });
      return false;
    }
  }
});

// Expose key lifecycle functions on global scope for inspection & testing
if (typeof globalThis !== 'undefined') {
  globalThis.syncRemoteControl = syncRemoteControl;
  globalThis.processAndAdoptControlEnvelope = processAndAdoptControlEnvelope;
  globalThis.syncDynamicContentScriptRegistration = syncDynamicContentScriptRegistration;
  globalThis.notifyTabsOfDisable = notifyTabsOfDisable;
  globalThis.enforcePrivilegedDisabled = enforcePrivilegedDisabled;
  globalThis.determineEnforcementOutcome = determineEnforcementOutcome;
}
if (typeof self !== 'undefined') {
  self.enforcePrivilegedDisabled = enforcePrivilegedDisabled;
}
