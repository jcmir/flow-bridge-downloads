/**
 * Flow Bridge Chrome Extension — Telemetry & Fleet Observability Client (S2B Correction V2)
 * 
 * Provides privacy-safe, authenticated, idempotent, and resilient operational telemetry
 * for the FLOW BRIDGE Chrome Extension fleet.
 * 
 * Invariants:
 * - Telemetry is strictly OPTIONAL observability. Failure to send telemetry MUST NEVER break Flow.
 * - Raw telemetry credential is NEVER exposed to page MAIN world and NEVER sent in JSON body.
 * - Whitelist-only schema: ZERO URLs, query strings, DOM, prompts, cookies, tokens, or PII transmitted.
 * - Logical event IDs are generated once and preserved across network retries for backend idempotency.
 * - Bounded queue (max 30 items) with priority retention and persistent backoff prevent floods and data loss.
 * - Serialized queue mutation lock protects against concurrent write races / lost events.
 * - Total isolation from S1 control verification: telemetry observes control adoption but cannot mutate S1.
 * - MAIN-world runtime signals are ADVISORY-only and cannot alter S1 control authority or patch gating.
 */

'use strict';

(function(exports) {

  // Authoritative Configuration & Enums matching S2A Backend Contract
  const PRODUCT = 'FLOW_BRIDGE_EXTENSION';
  const DEFAULT_BASE_ENDPOINT = 'https://flow-bridge-release.jcmir.workers.dev';
  const REGISTER_PATH = '/v1/extension/register';
  const TELEMETRY_PATH = '/v1/extension/telemetry';

  // Storage Keys in chrome.storage.local
  const STORAGE_KEYS = {
    INSTALLATION_ID: 'flow_bridge_installation_id',
    TELEMETRY_CREDENTIAL: 'flow_bridge_telemetry_credential',
    QUEUE: 'flow_bridge_telemetry_queue',
    META: 'flow_bridge_telemetry_meta',
    RETRY: 'flow_bridge_telemetry_retry',
    ERROR_DEDUP: 'flow_bridge_telemetry_error_dedup'
  };

  // Telemetry Health Lifecycle States (Completely isolated from S1 Control States)
  const HEALTH_STATES = Object.freeze({
    UNINITIALIZED: 'UNINITIALIZED',
    REGISTERING: 'REGISTERING',
    READY: 'READY',
    BACKOFF: 'BACKOFF',
    CREDENTIAL_UNAVAILABLE: 'CREDENTIAL_UNAVAILABLE',
    ERROR: 'ERROR'
  });

  // Frozen Backend S2A Enums
  const EVENT_TYPES = Object.freeze([
    'INSTALL',
    'STARTUP',
    'CONTROL_ADOPTED',
    'HEARTBEAT',
    'ERROR'
  ]);

  const CONTROL_STATES = Object.freeze([
    'ACTIVE',
    'MAINTENANCE',
    'UPDATE_REQUIRED',
    'DISABLED',
    'CONTROL_UNAVAILABLE'
  ]);

  const RUNTIME_STATES = Object.freeze([
    'INITIALIZING',
    'READY',
    'INJECTED',
    'PATCHED',
    'DISABLED',
    'BLOCKED',
    'ERROR',
    'UNKNOWN'
  ]);

  const FLOW_REACHABILITY_STATES = Object.freeze([
    'UNKNOWN',
    'FLOW_REACHED',
    'UNSUPPORTED_COUNTRY',
    'CONTROL_MAINTENANCE',
    'CONTROL_DISABLED',
    'UPDATE_REQUIRED',
    'RUNTIME_ERROR'
  ]);

  const ERROR_CATEGORIES = Object.freeze([
    'NONE',
    'NETWORK_ERROR',
    'CONTROL_FETCH_FAILED',
    'CONTROL_VERIFICATION_FAILED',
    'CONTROL_EXPIRED',
    'ROLLBACK_REJECTED',
    'PARSE_ERROR',
    'INJECTION_FAILED',
    'AUTH_FAILED',
    'RUNTIME_EXCEPTION',
    'UNKNOWN'
  ]);

  const PLATFORMS = Object.freeze([
    'MAC',
    'WINDOWS',
    'LINUX',
    'OTHER'
  ]);

  // Whitelisted keys permitted in outgoing telemetry JSON body (Exact 15 keys matching S2A backend schema)
  const ALLOWED_TELEMETRY_KEYS = new Set([
    'event_id',
    'installation_id',
    'product',
    'extension_version',
    'platform',
    'browser_major_version',
    'control_revision',
    'control_state',
    'compatibility_revision',
    'manifest_adopted',
    'runtime_state',
    'flow_reachability_state',
    'error_category',
    'event_type',
    'observed_at'
  ]);

  // Whitelisted keys permitted in outgoing registration JSON body
  const ALLOWED_REGISTRATION_KEYS = new Set([
    'installation_id',
    'product',
    'extension_version',
    'platform',
    'browser_major_version'
  ]);

  // Operational Queue & Backoff Limits
  const MAX_QUEUE_SIZE = 30;
  const INITIAL_BACKOFF_MS = 30000; // 30 seconds
  const MAX_BACKOFF_MS = 300000;    // 5 minutes
  const ERROR_DEDUP_WINDOW_MS = 300000; // 5 minutes per error category
  const HEARTBEAT_MIN_INTERVAL_MINUTES = 15;
  const HEARTBEAT_DEFAULT_MINUTES = 30;
  const RECENT_ACTIVITY_WINDOW_MS = 60 * 60 * 1000; // 60 minutes

  /**
   * Helper: Retrieve actual installed extension version from manifest without relying on page content
   */
  function getInstalledExtensionVersion() {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getManifest === 'function') {
        const manifest = chrome.runtime.getManifest();
        if (manifest && typeof manifest.version === 'string' && manifest.version.trim().length > 0) {
          return manifest.version.trim();
        }
      }
    } catch (_) {}
    return '0.1.0';
  }

  /**
   * Helper: Determine platform enum from navigator without leaking user agent
   */
  function detectPlatform() {
    try {
      if (typeof navigator !== 'undefined') {
        if (navigator.userAgentData && navigator.userAgentData.platform) {
          const p = navigator.userAgentData.platform.toLowerCase();
          if (p.includes('mac') || p.includes('darwin')) return 'MAC';
          if (p.includes('win')) return 'WINDOWS';
          if (p.includes('linux')) return 'LINUX';
        }
        if (navigator.platform) {
          const p = navigator.platform.toLowerCase();
          if (p.includes('mac') || p.includes('darwin')) return 'MAC';
          if (p.includes('win')) return 'WINDOWS';
          if (p.includes('linux')) return 'LINUX';
        }
        if (navigator.userAgent) {
          const ua = navigator.userAgent.toLowerCase();
          if (ua.includes('macintosh') || ua.includes('mac os')) return 'MAC';
          if (ua.includes('windows')) return 'WINDOWS';
          if (ua.includes('linux')) return 'LINUX';
        }
      }
    } catch (_) {}
    return 'OTHER';
  }

  /**
   * Helper: Extract browser major version integer only
   */
  function detectBrowserMajorVersion() {
    try {
      if (typeof navigator !== 'undefined') {
        if (navigator.userAgentData && Array.isArray(navigator.userAgentData.brands)) {
          const brand = navigator.userAgentData.brands.find(b => /Chrome|Chromium|Google Chrome/i.test(b.brand));
          if (brand && brand.version) {
            const parsed = parseInt(brand.version, 10);
            if (!isNaN(parsed) && parsed >= 1 && parsed <= 99999) return parsed;
          }
        }
        if (navigator.userAgent) {
          const match = navigator.userAgent.match(/Chrom(?:e|ium)\/(\d+)/);
          if (match && match[1]) {
            const parsed = parseInt(match[1], 10);
            if (!isNaN(parsed) && parsed >= 1 && parsed <= 99999) return parsed;
          }
        }
      }
    } catch (_) {}
    return null;
  }

  /**
   * Helper: Generate a cryptographically strong UUID v4
   */
  function generateUuid() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      bytes[6] = (bytes[6] & 0x0f) | 0x40; // Version 4
      bytes[8] = (bytes[8] & 0x3f) | 0x80; // Variant RFC 4122
      const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }
    throw new Error('SECURE_RNG_UNAVAILABLE');
  }

  /**
   * Helper: Compute persistent bounded backoff duration
   * Schedule: 30s, 60s, 120s, 240s, 300s max
   */
  function computeBackoffMs(attempt) {
    if (!attempt || attempt <= 1) return 30000;
    return Math.min(300000, 30000 * Math.pow(2, attempt - 1));
  }

  /**
   * Helper: Determine whether there has been recent Flow activity within the bounded window
   * Task 7: Control manifest refresh (last_fetch_timestamp) does NOT count as user Flow activity.
   * Only flow_bridge_last_update or timestamps from flow_bridge_latest_diag represent real Flow usage.
   */
  function hasRecentFlowActivity(storage, nowMs = Date.now(), windowMs = RECENT_ACTIVITY_WINDOW_MS) {
    if (!storage || typeof storage !== 'object') return false;
    let latest = 0;
    if (storage.flow_bridge_last_update) {
      const t = new Date(storage.flow_bridge_last_update).getTime();
      if (!isNaN(t) && t > latest) latest = t;
    }
    if (storage.flow_bridge_latest_diag) {
      const diagTime = storage.flow_bridge_latest_diag.last_update_timestamp || storage.flow_bridge_latest_diag.timestamp;
      if (diagTime) {
        const t = new Date(diagTime).getTime();
        if (!isNaN(t) && t > latest) latest = t;
      }
    }
    if (latest === 0) return false;
    return (nowMs - latest) <= windowMs;
  }

  /**
   * Helper: Build Full Sanitized Runtime Context from verified S1 record & local diagnostic state
   * Trust Boundary: Page/Main world diagnostics are ADVISORY only and cannot mutate S1 authority.
   * Task 4 & 5: Strong FLOW_REACHED definition & real /unsupported-country diagnostic routing.
   */
  function buildSanitizedRuntimeContext(verifiedControlRecord, localDiagStorage) {
    const result = {
      control_revision: undefined,
      control_state: 'CONTROL_UNAVAILABLE',
      compatibility_revision: undefined,
      manifest_adopted: 0,
      runtime_state: 'UNKNOWN',
      flow_reachability_state: 'UNKNOWN',
      error_category: 'NONE'
    };

    const hasVerified = Boolean(verifiedControlRecord && verifiedControlRecord.verified_manifest);
    if (hasVerified) {
      const manifest = verifiedControlRecord.verified_manifest;
      if (Number.isInteger(manifest.revision)) {
        result.control_revision = manifest.revision;
      }
      result.control_state = verifiedControlRecord.effective_state || 'UNKNOWN';
      if (Number.isInteger(manifest.compatibility_revision)) {
        result.compatibility_revision = manifest.compatibility_revision;
      }
      result.manifest_adopted = 1;
    } else {
      result.control_state = 'CONTROL_UNAVAILABLE';
      result.manifest_adopted = 0;
    }

    if (result.control_state === 'MAINTENANCE') {
      result.flow_reachability_state = 'CONTROL_MAINTENANCE';
      result.runtime_state = 'DISABLED';
    } else if (result.control_state === 'DISABLED') {
      result.flow_reachability_state = 'CONTROL_DISABLED';
      result.runtime_state = 'DISABLED';
    } else if (result.control_state === 'UPDATE_REQUIRED') {
      result.flow_reachability_state = 'UPDATE_REQUIRED';
      result.runtime_state = 'DISABLED';
    } else if (result.control_state === 'CONTROL_UNAVAILABLE') {
      result.flow_reachability_state = 'UNKNOWN';
      result.runtime_state = 'INITIALIZING';
    } else if (result.control_state === 'ACTIVE') {
      const diag = localDiagStorage ? localDiagStorage.flow_bridge_latest_diag : null;
      if (diag && (diag.current_url_path === '/unsupported-country' || diag.current_url_path === '/unsupported-country/' || diag.isUnsupportedCountry === true)) {
        result.flow_reachability_state = 'UNSUPPORTED_COUNTRY';
        result.runtime_state = 'BLOCKED';
      } else if (diag && diag.main_world_initialized === true) {
        const hooksIntact = Boolean(diag.hook_persistence && diag.hook_persistence.fetch_hook_intact === true && diag.hook_persistence.xhr_hook_intact === true);
        const transformationsObserved = Boolean(diag.transformation_applied_count && diag.transformation_applied_count > 0);

        if (hooksIntact && transformationsObserved) {
          result.flow_reachability_state = 'FLOW_REACHED';
          result.runtime_state = 'PATCHED';
        } else if (hooksIntact && !transformationsObserved) {
          result.flow_reachability_state = 'UNKNOWN';
          result.runtime_state = 'READY';
        } else {
          result.flow_reachability_state = 'UNKNOWN';
          result.runtime_state = 'ERROR';
        }
      } else if (verifiedControlRecord && verifiedControlRecord.allow_patch === true) {
        result.flow_reachability_state = 'UNKNOWN';
        result.runtime_state = 'READY';
      } else {
        result.flow_reachability_state = 'UNKNOWN';
        result.runtime_state = 'UNKNOWN';
      }
    }

    return result;
  }

  /**
   * Privacy-Safe Local Flow Reachability Classifier
   * Consumes local runtime state and outputs ONLY finite enum string.
   * Zero URL, pathname, or network parameters are leaked.
   */
  function classifyFlowReachability(context) {
    if (!context || typeof context !== 'object') {
      return 'UNKNOWN';
    }

    if (context.current_url_path === '/unsupported-country' || context.current_url_path === '/unsupported-country/' || context.isUnsupportedCountry === true) {
      return 'UNSUPPORTED_COUNTRY';
    }

    if (context.control_state === 'MAINTENANCE' || context.controlState === 'MAINTENANCE') {
      return 'CONTROL_MAINTENANCE';
    }

    if (context.control_state === 'DISABLED' || context.controlState === 'DISABLED') {
      return 'CONTROL_DISABLED';
    }

    if (context.control_state === 'UPDATE_REQUIRED' || context.controlState === 'UPDATE_REQUIRED') {
      return 'UPDATE_REQUIRED';
    }

    if (context.runtimeErrorCategory && context.runtimeErrorCategory !== 'NONE') {
      return 'RUNTIME_ERROR';
    }

    if (context.flow_reachability_state && FLOW_REACHABILITY_STATES.includes(context.flow_reachability_state)) {
      return context.flow_reachability_state;
    }

    if (context.main_world_initialized === true) {
      const hooksIntact = Boolean(context.hook_persistence && context.hook_persistence.fetch_hook_intact === true && context.hook_persistence.xhr_hook_intact === true);
      const transformationsObserved = Boolean(context.transformation_applied_count && context.transformation_applied_count > 0);
      if (hooksIntact && transformationsObserved) {
        return 'FLOW_REACHED';
      }
    }

    return 'UNKNOWN';
  }

  /**
   * Whitelist-Only Telemetry Event Builder
   * Strictly verifies and constructs the event payload.
   * Zero raw diagnostics, URLs, DOM, tokens, or PII can enter the payload.
   */
  function buildTelemetryEvent(options) {
    if (!options || typeof options !== 'object') {
      throw new Error('INVALID_TELEMETRY_OPTIONS');
    }

    const installationId = options.installation_id;
    if (!installationId || typeof installationId !== 'string') {
      throw new Error('MISSING_INSTALLATION_ID');
    }

    const eventType = options.event_type;
    if (!eventType || !EVENT_TYPES.includes(eventType)) {
      throw new Error('INVALID_EVENT_TYPE: ' + eventType);
    }

    const extensionVersion = options.extension_version || getInstalledExtensionVersion();
    const eventId = options.event_id || generateUuid();
    const observedAt = options.observed_at || new Date().toISOString();

    const payload = {
      event_id: eventId,
      installation_id: installationId,
      product: PRODUCT,
      extension_version: extensionVersion,
      event_type: eventType,
      observed_at: observedAt
    };

    if (options.platform && PLATFORMS.includes(options.platform)) {
      payload.platform = options.platform;
    }

    if (Number.isInteger(options.browser_major_version) && options.browser_major_version >= 1 && options.browser_major_version <= 99999) {
      payload.browser_major_version = options.browser_major_version;
    }

    if (Number.isInteger(options.control_revision) && options.control_revision >= 0) {
      payload.control_revision = options.control_revision;
    }

    if (options.control_state && CONTROL_STATES.includes(options.control_state)) {
      payload.control_state = options.control_state;
    }

    if (Number.isInteger(options.compatibility_revision) && options.compatibility_revision >= 0) {
      payload.compatibility_revision = options.compatibility_revision;
    }

    if (options.manifest_adopted !== undefined && options.manifest_adopted !== null) {
      payload.manifest_adopted = options.manifest_adopted ? 1 : 0;
    }

    if (options.runtime_state && RUNTIME_STATES.includes(options.runtime_state)) {
      payload.runtime_state = options.runtime_state;
    }

    if (options.flow_reachability_state && FLOW_REACHABILITY_STATES.includes(options.flow_reachability_state)) {
      payload.flow_reachability_state = options.flow_reachability_state;
    }

    if (options.error_category && ERROR_CATEGORIES.includes(options.error_category)) {
      payload.error_category = options.error_category;
    }

    // Hard verification: ensure zero forbidden keys leaked into payload
    for (const key of Object.keys(payload)) {
      if (!ALLOWED_TELEMETRY_KEYS.has(key)) {
        delete payload[key];
      }
    }

    return payload;
  }

  /**
   * Telemetry Client Class managing identity, queue, retry, and event dispatch
   */
  class TelemetryClient {
    constructor(options = {}) {
      this.baseEndpoint = options.baseEndpoint || DEFAULT_BASE_ENDPOINT;
      this.fetchFn = options.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
      this.storageAdapter = options.storageAdapter || (typeof chrome !== 'undefined' && chrome.storage ? chrome.storage.local : null);
      this.healthState = HEALTH_STATES.UNINITIALIZED;
      this._queueLockPromise = null;
      this._activeFlushPromise = null;
      this._activeRegistrationPromise = null;
      this.sessionStarted = false;
    }

    /**
     * Storage helper (supports async chrome.storage.local or Map/object for tests)
     */
    async _getStorage(keys) {
      if (!this.storageAdapter) return {};
      if (typeof this.storageAdapter.get === 'function') {
        return new Promise((resolve) => {
          this.storageAdapter.get(keys, (res) => resolve(res || {}));
        });
      }
      if (this.storageAdapter instanceof Map) {
        const res = {};
        for (const k of keys) {
          if (this.storageAdapter.has(k)) res[k] = this.storageAdapter.get(k);
        }
        return res;
      }
      return {};
    }

    async _setStorage(items) {
      if (!this.storageAdapter) return;
      if (typeof this.storageAdapter.set === 'function') {
        return new Promise((resolve) => {
          this.storageAdapter.set(items, () => resolve());
        });
      }
      if (this.storageAdapter instanceof Map) {
        for (const [k, v] of Object.entries(items)) {
          this.storageAdapter.set(k, v);
        }
      }
    }

    /**
     * Serialized execution wrapper for queue mutations (protects against lost-event races)
     */
    async _withQueueLock(fn) {
      const prevPromise = this._queueLockPromise || Promise.resolve();
      let releaseLock;
      const lockPromise = new Promise((resolve) => { releaseLock = resolve; });
      this._queueLockPromise = lockPromise;
      try {
        await prevPromise;
        return await fn();
      } finally {
        releaseLock();
        if (this._queueLockPromise === lockPromise) {
          this._queueLockPromise = null;
        }
      }
    }

    /**
     * Get or create persistent anonymous installation identity
     */
    async getOrCreateInstallationId() {
      const storage = await this._getStorage([STORAGE_KEYS.INSTALLATION_ID]);
      let id = storage[STORAGE_KEYS.INSTALLATION_ID];
      if (!id || typeof id !== 'string' || id.length !== 36) {
        id = generateUuid();
        await this._setStorage({ [STORAGE_KEYS.INSTALLATION_ID]: id });
      }
      return id;
    }

    /**
     * Retrieve local telemetry credential (never exposed to page context)
     */
    async getCredential() {
      const storage = await this._getStorage([STORAGE_KEYS.TELEMETRY_CREDENTIAL]);
      return storage[STORAGE_KEYS.TELEMETRY_CREDENTIAL] || null;
    }

    /**
     * Perform registration handshake with backend (coalesced via _activeRegistrationPromise mutex)
     * Task 8: Applies shared persistent retry/backoff policy on 429 / 5xx / network errors.
     */
    async register(customVersion) {
      if (this._activeRegistrationPromise) {
        return this._activeRegistrationPromise;
      }

      this._activeRegistrationPromise = (async () => {
        try {
          // Check persistent backoff before making registration request
          const retryStorage = await this._getStorage([STORAGE_KEYS.RETRY]);
          const retryMeta = retryStorage[STORAGE_KEYS.RETRY] || { retry_attempt: 0, next_retry_at: 0 };
          if (Date.now() < (retryMeta.next_retry_at || 0)) {
            this.healthState = HEALTH_STATES.BACKOFF;
            return { ok: false, error: 'BACKOFF_ACTIVE', next_retry_at: retryMeta.next_retry_at, retryable: true };
          }

          const installationId = await this.getOrCreateInstallationId();
          const existingCred = await this.getCredential();

          if (existingCred) {
            this.healthState = HEALTH_STATES.READY;
            return { ok: true, status: 'ALREADY_HAVE_CREDENTIAL', credential: existingCred };
          }

          this.healthState = HEALTH_STATES.REGISTERING;
          const version = customVersion || getInstalledExtensionVersion();
          const platform = detectPlatform();
          const browserMajor = detectBrowserMajorVersion();

          const payload = {
            installation_id: installationId,
            product: PRODUCT,
            extension_version: version,
            platform: platform
          };
          if (browserMajor !== null) {
            payload.browser_major_version = browserMajor;
          }

          const registerUrl = `${this.baseEndpoint}${REGISTER_PATH}`;
          let response;
          try {
            response = await this.fetchFn(registerUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
              },
              body: JSON.stringify(payload)
            });
          } catch (netErr) {
            this.healthState = HEALTH_STATES.BACKOFF;
            const attempt = (retryMeta.retry_attempt || 0) + 1;
            const backoffMs = computeBackoffMs(attempt);
            const nextRetryAt = Date.now() + backoffMs;
            await this._setStorage({
              [STORAGE_KEYS.RETRY]: { retry_attempt: attempt, next_retry_at: nextRetryAt }
            });
            if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.create === 'function') {
              try {
                chrome.alarms.create('fb_telemetry_retry_alarm', { when: nextRetryAt });
              } catch (_) {}
            }
            return { ok: false, error: 'NETWORK_ERROR', message: netErr.message, retryable: true };
          }

          if (response.status === 201) {
            const data = await response.json();
            if (data && data.telemetry_credential) {
              await this._setStorage({
                [STORAGE_KEYS.TELEMETRY_CREDENTIAL]: data.telemetry_credential,
                [STORAGE_KEYS.RETRY]: { retry_attempt: 0, next_retry_at: 0 }
              });
              if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.clear === 'function') {
                try {
                  chrome.alarms.clear('fb_telemetry_retry_alarm');
                } catch (_) {}
              }
              this.healthState = HEALTH_STATES.READY;
              return { ok: true, event: 'registered', credential: data.telemetry_credential };
            }
          }

          if (response.status === 200) {
            const data = await response.json();
            if (data && data.event === 'registered_repaired' && data.telemetry_credential) {
              await this._setStorage({
                [STORAGE_KEYS.TELEMETRY_CREDENTIAL]: data.telemetry_credential,
                [STORAGE_KEYS.RETRY]: { retry_attempt: 0, next_retry_at: 0 }
              });
              if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.clear === 'function') {
                try {
                  chrome.alarms.clear('fb_telemetry_retry_alarm');
                } catch (_) {}
              }
              this.healthState = HEALTH_STATES.READY;
              return { ok: true, event: 'registered_repaired', credential: data.telemetry_credential };
            }
            if (data && data.event === 'already_registered') {
              const recheckCred = await this.getCredential();
              if (recheckCred) {
                this.healthState = HEALTH_STATES.READY;
                return { ok: true, event: 'already_registered', credential: recheckCred };
              }
              // Lost local credential case: enter CREDENTIAL_UNAVAILABLE without looping
              this.healthState = HEALTH_STATES.CREDENTIAL_UNAVAILABLE;
              return { ok: false, error: 'CREDENTIAL_UNAVAILABLE', message: 'Backend reports already_registered but local credential is absent' };
            }
          }

          if (response.status === 429 || (response.status >= 500 && response.status <= 599)) {
            this.healthState = HEALTH_STATES.BACKOFF;
            const attempt = (retryMeta.retry_attempt || 0) + 1;
            const backoffMs = computeBackoffMs(attempt);
            const nextRetryAt = Date.now() + backoffMs;
            await this._setStorage({
              [STORAGE_KEYS.RETRY]: { retry_attempt: attempt, next_retry_at: nextRetryAt }
            });
            if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.create === 'function') {
              try {
                chrome.alarms.create('fb_telemetry_retry_alarm', { when: nextRetryAt });
              } catch (_) {}
            }
            return { ok: false, error: 'SERVER_TEMPORARY_ERROR', status: response.status, retryable: true };
          }

          this.healthState = HEALTH_STATES.ERROR;
          return { ok: false, error: 'REGISTRATION_REJECTED', status: response.status, retryable: false };
        } finally {
          this._activeRegistrationPromise = null;
        }
      })();

      return this._activeRegistrationPromise;
    }

    /**
     * Enqueue a validated telemetry event into persistent bounded storage queue
     * Serialized under _withQueueLock with priority retention and heartbeat coalescing
     */
    async enqueue(eventOptions) {
      return await this._withQueueLock(async () => {
        try {
          const installationId = await this.getOrCreateInstallationId();
          const event = buildTelemetryEvent({
            ...eventOptions,
            installation_id: installationId,
            platform: eventOptions.platform || detectPlatform(),
            browser_major_version: eventOptions.browser_major_version !== undefined ? eventOptions.browser_major_version : detectBrowserMajorVersion()
          });

          const storage = await this._getStorage([STORAGE_KEYS.QUEUE]);
          let queue = Array.isArray(storage[STORAGE_KEYS.QUEUE]) ? storage[STORAGE_KEYS.QUEUE] : [];

          // Heartbeat coalescing: at most one pending unsent HEARTBEAT in queue
          if (event.event_type === 'HEARTBEAT') {
            const hbIndex = queue.findIndex(e => e.event_type === 'HEARTBEAT');
            if (hbIndex !== -1) {
              queue[hbIndex] = event;
              await this._setStorage({ [STORAGE_KEYS.QUEUE]: queue });
              return { enqueued: true, event_id: event.event_id, coalesced: true };
            }
          }

          // Priority queue bounds enforcement (Capacity limit: 30)
          if (queue.length >= MAX_QUEUE_SIZE) {
            const isIncomingHigh = event.event_type === 'CONTROL_ADOPTED' || event.event_type === 'ERROR';
            if (isIncomingHigh) {
              // Find and evict oldest low-priority event (HEARTBEAT or STARTUP)
              const lowIndex = queue.findIndex(e => e.event_type === 'HEARTBEAT' || e.event_type === 'STARTUP');
              if (lowIndex !== -1) {
                queue.splice(lowIndex, 1);
              } else {
                // Queue contains only high-priority events: evict oldest high-priority
                queue.shift();
              }
              queue.push(event);
            } else {
              // Incoming is low-priority (HEARTBEAT or STARTUP)
              const lowIndex = queue.findIndex(e => e.event_type === 'HEARTBEAT' || e.event_type === 'STARTUP');
              if (lowIndex !== -1) {
                queue.splice(lowIndex, 1);
                queue.push(event);
              } else {
                // Queue contains only high-priority events: DROP the incoming low-priority event
                return { enqueued: false, dropped: true, reason: 'QUEUE_FULL_HIGH_PRIORITY_PRESERVED' };
              }
            }
          } else {
            queue.push(event);
          }

          await this._setStorage({ [STORAGE_KEYS.QUEUE]: queue });
          return { enqueued: true, event_id: event.event_id };
        } catch (err) {
          return { enqueued: false, error: err.message };
        }
      });
    }

    /**
     * Flush queue to backend using Header-Only Authentication, Mutex, and Exact Event ID Dequeue
     */
    async flushQueue() {
      if (this._activeFlushPromise) {
        return this._activeFlushPromise;
      }

      this._activeFlushPromise = (async () => {
        try {
          // 1. Check persistent backoff state
          const retryStorage = await this._getStorage([STORAGE_KEYS.RETRY]);
          const retryMeta = retryStorage[STORAGE_KEYS.RETRY] || { retry_attempt: 0, next_retry_at: 0 };
          if (Date.now() < (retryMeta.next_retry_at || 0)) {
            this.healthState = HEALTH_STATES.BACKOFF;
            return { status: 'BACKOFF_ACTIVE', next_retry_at: retryMeta.next_retry_at };
          }

          // 2. Ensure valid credential
          let credential = await this.getCredential();
          if (!credential) {
            const regRes = await this.register();
            if (!regRes.ok) {
              if (regRes.error === 'CREDENTIAL_UNAVAILABLE') {
                this.healthState = HEALTH_STATES.CREDENTIAL_UNAVAILABLE;
              }
              return { status: 'REGISTRATION_PENDING', reason: regRes.error };
            }
            credential = await this.getCredential();
          }

          if (!credential) {
            return { status: 'CREDENTIAL_UNAVAILABLE' };
          }

          let sentCount = 0;
          const telemetryUrl = `${this.baseEndpoint}${TELEMETRY_PATH}`;

          while (true) {
            // Step A: Pick next event under queue lock
            let currentEvent = null;
            await this._withQueueLock(async () => {
              const storage = await this._getStorage([STORAGE_KEYS.QUEUE]);
              const queue = Array.isArray(storage[STORAGE_KEYS.QUEUE]) ? storage[STORAGE_KEYS.QUEUE] : [];
              if (queue.length > 0) {
                currentEvent = queue[0];
              }
            });

            if (!currentEvent) {
              return { status: 'FLUSH_COMPLETE', sentCount };
            }

            // Step B: Send HTTP request outside queue lock
            let responseStatus = null;
            let fetchError = null;

            try {
              const response = await this.fetchFn(telemetryUrl, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Accept': 'application/json',
                  'Authorization': `Bearer ${credential}`
                },
                body: JSON.stringify(currentEvent)
              });
              responseStatus = response.status;
            } catch (netErr) {
              fetchError = netErr;
            }

            // Step C: Handle response / retry
            if (fetchError || (responseStatus >= 500 && responseStatus <= 599) || responseStatus === 429) {
              this.healthState = HEALTH_STATES.BACKOFF;
              const curRetryStorage = await this._getStorage([STORAGE_KEYS.RETRY]);
              const prevAttempt = (curRetryStorage[STORAGE_KEYS.RETRY] && curRetryStorage[STORAGE_KEYS.RETRY].retry_attempt) || 0;
              const nextAttempt = prevAttempt + 1;
              const backoffMs = computeBackoffMs(nextAttempt);
              const nextRetryAt = Date.now() + backoffMs;

              await this._setStorage({
                [STORAGE_KEYS.RETRY]: { retry_attempt: nextAttempt, next_retry_at: nextRetryAt }
              });

              if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.create === 'function') {
                try {
                  chrome.alarms.create('fb_telemetry_retry_alarm', { when: nextRetryAt });
                } catch (_) {}
              }

              return { status: 'BACKOFF_TRIGGERED', retry_attempt: nextAttempt, next_retry_at: nextRetryAt };
            }

            if (responseStatus === 404) {
              // 404 Unknown Installation Recovery
              await this._setStorage({ [STORAGE_KEYS.TELEMETRY_CREDENTIAL]: null });
              this.healthState = HEALTH_STATES.REGISTERING;

              const reregRes = await this.register();
              if (reregRes.ok && reregRes.credential) {
                credential = reregRes.credential;
                continue; // Retry same event with fresh credential
              } else {
                this.healthState = HEALTH_STATES.CREDENTIAL_UNAVAILABLE;
                return { status: 'RECOVERY_REGISTRATION_FAILED', error: reregRes.error };
              }
            }

            if (responseStatus === 401) {
              this.healthState = HEALTH_STATES.CREDENTIAL_UNAVAILABLE;
              return { status: 'CREDENTIAL_UNAVAILABLE' };
            }

            // Terminal response (200 OK / idempotent_duplicate, 400, 409, 413, or unknown):
            // Remove EXACT event_id from storage under queue lock
            await this._withQueueLock(async () => {
              const storage = await this._getStorage([STORAGE_KEYS.QUEUE, STORAGE_KEYS.META]);
              let queue = Array.isArray(storage[STORAGE_KEYS.QUEUE]) ? storage[STORAGE_KEYS.QUEUE] : [];
              const idx = queue.findIndex(e => e.event_id === currentEvent.event_id);
              if (idx !== -1) {
                queue.splice(idx, 1);
              }
              let meta = storage[STORAGE_KEYS.META] || {};
              meta.last_http_status = responseStatus;
              meta.last_event_type = currentEvent.event_type;
              if (responseStatus === 200) {
                meta.last_success_at = new Date().toISOString();
              } else {
                meta.last_error_at = new Date().toISOString();
              }
              await this._setStorage({
                [STORAGE_KEYS.QUEUE]: queue,
                [STORAGE_KEYS.META]: meta
              });
            });

            if (responseStatus === 200) {
              sentCount++;
              await this._setStorage({
                [STORAGE_KEYS.RETRY]: { retry_attempt: 0, next_retry_at: 0 }
              });
              if (typeof chrome !== 'undefined' && chrome.alarms && typeof chrome.alarms.clear === 'function') {
                try {
                  chrome.alarms.clear('fb_telemetry_retry_alarm');
                } catch (_) {}
              }
              this.healthState = HEALTH_STATES.READY;
            }
          }
        } catch (fatalErr) {
          return { status: 'FLUSH_FAILED', error: fatalErr.message };
        } finally {
          this._activeFlushPromise = null;
        }
      })();

      return this._activeFlushPromise;
    }

    /**
     * Record Control Adoption event (Triggered when S1 verifies and adopts new revision)
     */
    async emitControlAdopted(adoptedRecord, runtimeContext = {}) {
      if (!adoptedRecord || !adoptedRecord.verified_manifest) return;
      const manifest = adoptedRecord.verified_manifest;
      await this.enqueue({
        event_type: 'CONTROL_ADOPTED',
        control_revision: manifest.revision,
        control_state: adoptedRecord.effective_state,
        compatibility_revision: manifest.compatibility_revision,
        manifest_adopted: 1,
        runtime_state: runtimeContext.runtime_state || (adoptedRecord.allow_patch === true ? 'READY' : 'DISABLED'),
        flow_reachability_state: classifyFlowReachability({
          control_state: adoptedRecord.effective_state,
          ...runtimeContext
        }),
        error_category: 'NONE'
      });
      this.flushQueue().catch(() => {});
    }

    /**
     * Record Startup event (deduped per logical session)
     */
    async emitStartup(runtimeContext = {}) {
      if (this.sessionStarted) return;
      this.sessionStarted = true;

      const eventOpts = {
        event_type: 'STARTUP',
        runtime_state: runtimeContext.runtime_state || 'INITIALIZING',
        control_state: runtimeContext.control_state || 'CONTROL_UNAVAILABLE',
        manifest_adopted: runtimeContext.manifest_adopted !== undefined ? runtimeContext.manifest_adopted : 0,
        flow_reachability_state: classifyFlowReachability(runtimeContext),
        error_category: 'NONE'
      };
      if (Number.isInteger(runtimeContext.control_revision)) {
        eventOpts.control_revision = runtimeContext.control_revision;
      }
      if (Number.isInteger(runtimeContext.compatibility_revision)) {
        eventOpts.compatibility_revision = runtimeContext.compatibility_revision;
      }

      await this.enqueue(eventOpts);
      this.flushQueue().catch(() => {});
    }

    /**
     * Record Heartbeat event
     */
    async emitHeartbeat(runtimeContext = {}) {
      const eventOpts = {
        event_type: 'HEARTBEAT',
        runtime_state: runtimeContext.runtime_state || 'READY',
        control_state: runtimeContext.control_state || 'CONTROL_UNAVAILABLE',
        manifest_adopted: runtimeContext.manifest_adopted !== undefined ? runtimeContext.manifest_adopted : 0,
        flow_reachability_state: classifyFlowReachability(runtimeContext),
        error_category: 'NONE'
      };
      if (Number.isInteger(runtimeContext.control_revision)) {
        eventOpts.control_revision = runtimeContext.control_revision;
      }
      if (Number.isInteger(runtimeContext.compatibility_revision)) {
        eventOpts.compatibility_revision = runtimeContext.compatibility_revision;
      }

      await this.enqueue(eventOpts);
      this.flushQueue().catch(() => {});
    }

    /**
     * Record Error event with persistent dedup across MV3 Service Worker restarts
     */
    async emitError(errorCategory, runtimeContext = {}) {
      const category = ERROR_CATEGORIES.includes(errorCategory) ? errorCategory : 'UNKNOWN';
      const now = Date.now();

      const storage = await this._getStorage([STORAGE_KEYS.ERROR_DEDUP]);
      const dedupMap = (storage && typeof storage[STORAGE_KEYS.ERROR_DEDUP] === 'object' && storage[STORAGE_KEYS.ERROR_DEDUP])
        ? storage[STORAGE_KEYS.ERROR_DEDUP]
        : {};
      const lastReported = dedupMap[category] || 0;

      if (now - lastReported < ERROR_DEDUP_WINDOW_MS) {
        return { dropped: true, reason: 'RATE_LIMITED_CATEGORY' };
      }

      dedupMap[category] = now;
      await this._setStorage({ [STORAGE_KEYS.ERROR_DEDUP]: dedupMap });

      const eventOpts = {
        event_type: 'ERROR',
        error_category: category,
        runtime_state: 'ERROR',
        control_state: runtimeContext.control_state || 'CONTROL_UNAVAILABLE',
        manifest_adopted: runtimeContext.manifest_adopted !== undefined ? runtimeContext.manifest_adopted : 0,
        flow_reachability_state: classifyFlowReachability({
          runtimeErrorCategory: category,
          ...runtimeContext
        })
      };
      if (Number.isInteger(runtimeContext.control_revision)) {
        eventOpts.control_revision = runtimeContext.control_revision;
      }
      if (Number.isInteger(runtimeContext.compatibility_revision)) {
        eventOpts.compatibility_revision = runtimeContext.compatibility_revision;
      }

      await this.enqueue(eventOpts);
      this.flushQueue().catch(() => {});
      return { dropped: false, error_category: category };
    }

    /**
     * Read-only diagnostics snapshot for local operator/popup inspection
     * Never leaks raw credential or Authorization header.
     */
    async getDiagnostics(isOperator = false) {
      const storage = await this._getStorage([
        STORAGE_KEYS.INSTALLATION_ID,
        STORAGE_KEYS.TELEMETRY_CREDENTIAL,
        STORAGE_KEYS.QUEUE,
        STORAGE_KEYS.META,
        STORAGE_KEYS.RETRY
      ]);
      const queue = Array.isArray(storage[STORAGE_KEYS.QUEUE]) ? storage[STORAGE_KEYS.QUEUE] : [];
      const meta = storage[STORAGE_KEYS.META] || {};
      const retry = storage[STORAGE_KEYS.RETRY] || {};
      const instId = storage[STORAGE_KEYS.INSTALLATION_ID];

      return {
        telemetry_enabled: true,
        health_state: this.healthState,
        installation_id: instId ? (isOperator ? instId : 'ANONYMOUS_SET') : 'UNSET',
        has_credential: Boolean(storage[STORAGE_KEYS.TELEMETRY_CREDENTIAL]),
        pending_events_count: queue.length,
        retry_attempt: retry.retry_attempt || 0,
        next_retry_at: retry.next_retry_at || 0,
        last_event_type: meta.last_event_type || null,
        last_http_status: meta.last_http_status || null,
        last_success_at: meta.last_success_at || null,
        last_error_at: meta.last_error_at || null
      };
    }
  }

  // Export module members
  exports.PRODUCT = PRODUCT;
  exports.DEFAULT_BASE_ENDPOINT = DEFAULT_BASE_ENDPOINT;
  exports.STORAGE_KEYS = STORAGE_KEYS;
  exports.HEALTH_STATES = HEALTH_STATES;
  exports.EVENT_TYPES = EVENT_TYPES;
  exports.CONTROL_STATES = CONTROL_STATES;
  exports.RUNTIME_STATES = RUNTIME_STATES;
  exports.FLOW_REACHABILITY_STATES = FLOW_REACHABILITY_STATES;
  exports.ERROR_CATEGORIES = ERROR_CATEGORIES;
  exports.PLATFORMS = PLATFORMS;
  exports.ALLOWED_TELEMETRY_KEYS = ALLOWED_TELEMETRY_KEYS;
  exports.ALLOWED_REGISTRATION_KEYS = ALLOWED_REGISTRATION_KEYS;
  exports.MAX_QUEUE_SIZE = MAX_QUEUE_SIZE;
  exports.HEARTBEAT_MIN_INTERVAL_MINUTES = HEARTBEAT_MIN_INTERVAL_MINUTES;
  exports.HEARTBEAT_DEFAULT_MINUTES = HEARTBEAT_DEFAULT_MINUTES;
  exports.RECENT_ACTIVITY_WINDOW_MS = RECENT_ACTIVITY_WINDOW_MS;

  exports.detectPlatform = detectPlatform;
  exports.detectBrowserMajorVersion = detectBrowserMajorVersion;
  exports.generateUuid = generateUuid;
  exports.getInstalledExtensionVersion = getInstalledExtensionVersion;
  exports.computeBackoffMs = computeBackoffMs;
  exports.hasRecentFlowActivity = hasRecentFlowActivity;
  exports.buildSanitizedRuntimeContext = buildSanitizedRuntimeContext;
  exports.classifyFlowReachability = classifyFlowReachability;
  exports.buildTelemetryEvent = buildTelemetryEvent;
  exports.TelemetryClient = TelemetryClient;

})(typeof self !== 'undefined'
  ? (self.__FLOW_BRIDGE_TELEMETRY__ = self.__FLOW_BRIDGE_TELEMETRY__ || {})
  : (typeof global !== 'undefined' ? (global.__FLOW_BRIDGE_TELEMETRY__ = global.__FLOW_BRIDGE_TELEMETRY__ || {}) : this));

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof self !== 'undefined' ? self.__FLOW_BRIDGE_TELEMETRY__ : (typeof global !== 'undefined' ? global.__FLOW_BRIDGE_TELEMETRY__ : {}));
}
